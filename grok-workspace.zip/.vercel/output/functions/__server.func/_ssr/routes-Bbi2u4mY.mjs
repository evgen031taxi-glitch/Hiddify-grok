import { i as __toESM } from "../_runtime.mjs";
import { U as isRedirect, b as require_jsx_runtime, q as require_react, y as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { a as RefreshCw, c as Plus, d as FolderOpen, f as FileUp, i as Sparkles, l as Play, o as Radio, p as ClipboardPaste, r as Trash2, s as QrCode, t as X, u as Gauge } from "../_libs/lucide-react.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Bbi2u4mY.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function useServerFn(serverFn) {
	const router = useRouter();
	return import_react.useCallback(async (...args) => {
		try {
			const res = await serverFn(...args);
			if (isRedirect(res)) throw res;
			return res;
		} catch (err) {
			if (isRedirect(err)) {
				err.options._fromLocation = router.stores.location.get();
				return router.navigate(router.resolveRedirect(err).options);
			}
			throw err;
		}
	}, [router, serverFn]);
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var fetchSubscription = createServerFn({ method: "POST" }).validator((input) => {
	if (!input || typeof input !== "object" || !("url" in input)) throw new Error("Нужна ссылка");
	const url = String(input.url ?? "").trim();
	if (url.length < 8 || url.length > 2048) throw new Error("Ссылка слишком короткая или длинная");
	return { url };
}).handler(createSsrRpc("ee3dd3b7eb689fbfccce4a0150834ca28ce5bb042732362907d047616557bc7b"));
var SKIP_TYPES = /* @__PURE__ */ new Set([
	"selector",
	"urltest",
	"direct",
	"block",
	"dns",
	"reject",
	"compatible",
	"loadbalance",
	"fallback"
]);
var KEEPERS = /* @__PURE__ */ new Set([
	"vless",
	"vmess",
	"trojan",
	"ss",
	"shadowsocks",
	"hysteria",
	"hysteria2",
	"hy2",
	"tuic",
	"wireguard",
	"socks",
	"socks5",
	"http",
	"ssh",
	"anytls",
	"mieru"
]);
function unwrapSubUrl(raw) {
	let s = raw.trim();
	const prefixes = [
		"happ://add/",
		"happ://crypt/",
		"happ://",
		"hiddify://import/",
		"hiddify://install-config/?url=",
		"hiddify://install-config?url=",
		"clash://install-config?url=",
		"clashmeta://install-config?url=",
		"v2rayng://install-sub?url=",
		"v2rayng://install-config?url=",
		"streisand://import/"
	];
	const lower = s.toLowerCase();
	for (const prefix of prefixes) if (lower.startsWith(prefix)) {
		s = s.slice(prefix.length);
		break;
	}
	if (!/^https?:\/\//i.test(s) && /url=/i.test(s)) {
		const cut = s.split(/url=/i)[1] ?? "";
		s = cut.split("&")[0] ?? cut;
	}
	try {
		s = decodeURIComponent(s);
	} catch {}
	return s.trim();
}
function parseUserinfo(header) {
	if (!header) return void 0;
	const info = {};
	for (const part of header.split(";")) {
		const [keyRaw, valueRaw] = part.split("=");
		const key = keyRaw?.trim();
		const value = Number(valueRaw?.trim());
		if (!key || !Number.isFinite(value)) continue;
		if (key === "upload") info.upload = value;
		else if (key === "download") info.download = value;
		else if (key === "total") info.total = value;
		else if (key === "expire") info.expire = value;
	}
	return Object.keys(info).length ? info : void 0;
}
function parseSubscription(raw) {
	const text = raw.replace(/^\uFEFF/, "").trim();
	if (!text) return [];
	const direct = parseAny(text);
	if (direct.length) return direct;
	const decoded = tryDecodeBase64(text);
	if (!decoded || decoded === text) return [];
	return parseAny(decoded);
}
function parseAny(text) {
	const trimmed = text.trim();
	if (trimmed.startsWith("{") || trimmed.startsWith("[")) {
		const fromJson = parseJson(trimmed);
		if (fromJson.length) return fromJson;
	}
	if (/^\s*proxies:/m.test(trimmed) || trimmed.includes("\nproxies:")) {
		const fromClash = parseClash(trimmed);
		if (fromClash.length) return fromClash;
	}
	return parseLines(trimmed);
}
function parseLines(text) {
	const nodes = [];
	const seen = /* @__PURE__ */ new Set();
	for (const lineRaw of text.split(/\r?\n/)) {
		const line = lineRaw.trim();
		if (!line || line.startsWith("#") || line.startsWith("//")) continue;
		const node = parseShare(line);
		if (!node) continue;
		pushNode(nodes, seen, node);
	}
	return nodes;
}
function pushNode(nodes, seen, node) {
	let id = node.id;
	let n = 2;
	while (seen.has(id)) {
		id = `${node.id}#${n}`;
		n += 1;
	}
	seen.add(id);
	nodes.push({
		...node,
		id
	});
}
function parseShare(line) {
	const match = line.match(/^(vless|vmess|trojan|ss|hy2|hysteria2|hysteria|tuic|socks5|socks|anytls|wireguard):\/\/(\S+)/i);
	if (!match) return null;
	const protocol = (match[1] ?? "").toLowerCase();
	const rest = match[2] ?? "";
	if (protocol === "vmess") return parseVmess(rest);
	if (protocol === "ss") return parseSs(rest);
	return parseStandard(protocol === "hy2" ? "hysteria2" : protocol, rest);
}
function parseStandard(protocol, rest) {
	const { main, name } = splitName(rest);
	const noQuery = main.split("?")[0] ?? main;
	const at = noQuery.lastIndexOf("@");
	const hp = splitHostPort(at >= 0 ? noQuery.slice(at + 1) : noQuery);
	if (!hp) return null;
	return makeNode(protocol, hp.host, hp.port, name || `${protocol} ${hp.host}`);
}
function parseSs(rest) {
	const { main, name } = splitName(rest);
	const noQuery = main.split("?")[0] ?? main;
	if (noQuery.includes("@")) {
		const at = noQuery.lastIndexOf("@");
		const hp = splitHostPort(noQuery.slice(at + 1));
		if (!hp) return null;
		return makeNode("ss", hp.host, hp.port, name || `ss ${hp.host}`);
	}
	const decoded = tryDecodeBase64(noQuery);
	if (!decoded) return null;
	const at = decoded.lastIndexOf("@");
	if (at < 0) return null;
	const hp = splitHostPort(decoded.slice(at + 1));
	if (!hp) return null;
	return makeNode("ss", hp.host, hp.port, name || `ss ${hp.host}`);
}
function parseVmess(payload) {
	const decoded = tryDecodeBase64(payload.split("#")[0] ?? payload);
	if (!decoded) return null;
	let data;
	try {
		data = JSON.parse(decoded);
	} catch {
		return null;
	}
	if (!data || typeof data !== "object") return null;
	const rec = data;
	const host = typeof rec.add === "string" ? rec.add : "";
	const port = rec.port != null ? String(rec.port) : "";
	const name = typeof rec.ps === "string" && rec.ps ? rec.ps : `vmess ${host}`;
	if (!host) return null;
	return makeNode("vmess", host, port || "443", name);
}
function parseJson(text) {
	let data;
	try {
		data = JSON.parse(text);
	} catch {
		return [];
	}
	const list = extractList(data);
	const nodes = [];
	const seen = /* @__PURE__ */ new Set();
	for (const item of list) {
		if (!item || typeof item !== "object") continue;
		const rec = item;
		const typeRaw = typeof rec.type === "string" ? rec.type.toLowerCase() : "";
		if (!typeRaw || SKIP_TYPES.has(typeRaw)) continue;
		const protocol = typeRaw === "shadowsocks" ? "ss" : typeRaw;
		if (!KEEPERS.has(protocol) && !KEEPERS.has(typeRaw)) continue;
		const host = typeof rec.server === "string" && rec.server || typeof rec.address === "string" && rec.address || "";
		const portValue = rec.server_port ?? rec.port ?? rec.serverPort;
		const port = portValue != null ? String(portValue) : "443";
		const name = typeof rec.tag === "string" && rec.tag || typeof rec.name === "string" && rec.name || `${protocol} ${host}`;
		if (!host) continue;
		const node = makeNode(protocol, host, port, name);
		if (node) pushNode(nodes, seen, node);
	}
	return nodes;
}
function extractList(data) {
	if (Array.isArray(data)) return data;
	if (!data || typeof data !== "object") return [];
	const rec = data;
	if (Array.isArray(rec.outbounds)) return rec.outbounds;
	if (Array.isArray(rec.proxies)) return rec.proxies;
	if (Array.isArray(rec.servers)) return rec.servers;
	return [];
}
function parseClash(text) {
	const lines = text.split(/\r?\n/);
	let inProxies = false;
	const nodes = [];
	const seen = /* @__PURE__ */ new Set();
	let cur = null;
	const flush = () => {
		if (!cur?.server || !cur.type) {
			cur = null;
			return;
		}
		const protocol = cur.type.toLowerCase();
		if (SKIP_TYPES.has(protocol)) {
			cur = null;
			return;
		}
		const node = makeNode(protocol === "shadowsocks" ? "ss" : protocol, cur.server, cur.port || "443", cur.name || `${protocol} ${cur.server}`);
		if (node) pushNode(nodes, seen, node);
		cur = null;
	};
	for (const line of lines) {
		if (!inProxies) {
			if (/^proxies:\s*(\[|$)/.test(line.trim()) || /^proxies:\s*$/.test(line)) {
				inProxies = true;
				const inline = line.split(/^proxies:\s*/).pop() ?? "";
				if (inline.trim().startsWith("[")) {
					const block = collectFlow(inline.trim());
					for (const node of parseFlowArray(block)) pushNode(nodes, seen, node);
					return nodes;
				}
			}
			continue;
		}
		if (/^[A-Za-z0-9_-]+:\s*$/.test(line)) {
			flush();
			break;
		}
		const flow = line.match(/^\s*-\s*\{(.+)\}\s*$/);
		if (flow?.[1]) {
			flush();
			const node = parseFlowItem(flow[1]);
			if (node) pushNode(nodes, seen, node);
			continue;
		}
		const named = line.match(/^\s*-\s*name:\s*(.+?)\s*$/);
		if (named?.[1]) {
			flush();
			cur = { name: unquote(named[1]) };
			continue;
		}
		if (!cur) continue;
		const kv = line.match(/^\s+(type|server|port):\s*(.+?)\s*$/);
		if (!kv) continue;
		const key = kv[1];
		const value = unquote(kv[2] ?? "");
		if (key === "type") cur.type = value;
		else if (key === "server") cur.server = value;
		else if (key === "port") cur.port = value;
	}
	flush();
	return nodes;
}
function collectFlow(start) {
	return start;
}
function parseFlowArray(block) {
	const parts = block.replace(/^\[/, "").replace(/\]\s*$/, "").split(/\}\s*,\s*\{/);
	const nodes = [];
	for (const part of parts) {
		const node = parseFlowItem(part.replace(/^\{/, "").replace(/\}$/, ""));
		if (node) nodes.push(node);
	}
	return nodes;
}
function parseFlowItem(body) {
	const pick = (key) => {
		const m = body.match(new RegExp(`(?:^|,)\\s*${key}\\s*:\\s*("[^"]*"|'[^']*'|[^,}]+)`));
		return m?.[1] ? unquote(m[1]) : "";
	};
	const name = pick("name");
	const type = pick("type");
	const server = pick("server");
	const port = pick("port");
	if (!type || !server || SKIP_TYPES.has(type.toLowerCase())) return null;
	const protocol = type.toLowerCase() === "shadowsocks" ? "ss" : type.toLowerCase();
	return makeNode(protocol, server, port || "443", name || `${protocol} ${server}`);
}
function splitName(rest) {
	const hash = rest.lastIndexOf("#");
	if (hash < 0) return {
		main: rest,
		name: ""
	};
	let name = rest.slice(hash + 1);
	try {
		name = decodeURIComponent(name.replace(/\+/g, " "));
	} catch {}
	return {
		main: rest.slice(0, hash),
		name
	};
}
function splitHostPort(value) {
	const hp = value.replace(/\/$/, "");
	if (!hp) return null;
	if (hp.startsWith("[")) {
		const end = hp.indexOf("]");
		if (end < 0) return null;
		return cleanHostPort(hp.slice(1, end), hp.slice(end + 1).replace(/^:/, "") || "443");
	}
	const colon = hp.lastIndexOf(":");
	if (colon < 0) return cleanHostPort(hp, "443");
	return cleanHostPort(hp.slice(0, colon), hp.slice(colon + 1) || "443");
}
function cleanHostPort(host, port) {
	const h = host.trim();
	const p = (port.trim().match(/^\d{1,5}/)?.[0] ?? "").replace(/^0+(?=\d)/, "");
	if (!h || h.length > 253 || /\s/.test(h)) return null;
	const n = Number(p || "443");
	if (!Number.isInteger(n) || n < 1 || n > 65535) return null;
	return {
		host: h,
		port: String(n)
	};
}
function makeNode(protocol, host, port, name) {
	const hp = cleanHostPort(host, port);
	if (!hp) return null;
	const proto = protocol.toLowerCase();
	const label = name.replace(/\s+/g, " ").trim().slice(0, 80) || `${proto} ${hp.host}`;
	return {
		id: `${proto}|${hp.host}|${hp.port}|${label}`.slice(0, 180),
		name: label,
		protocol: proto,
		host: hp.host,
		port: hp.port
	};
}
function unquote(value) {
	const trimmed = value.trim().replace(/\s+#.*$/, "");
	if (trimmed.startsWith("\"") && trimmed.endsWith("\"") || trimmed.startsWith("'") && trimmed.endsWith("'")) return trimmed.slice(1, -1);
	return trimmed;
}
function tryDecodeBase64(value) {
	const compact = value.replace(/\s/g, "");
	if (compact.length < 8 || !/^[A-Za-z0-9+/_=-]+$/.test(compact)) return null;
	const pad = compact.replace(/-/g, "+").replace(/_/g, "/");
	const padded = pad + "=".repeat((4 - pad.length % 4) % 4);
	try {
		const bytes = typeof atob === "function" ? Uint8Array.from(atob(padded), (c) => c.charCodeAt(0)) : Uint8Array.from(Buffer.from(padded, "base64"));
		const text = new TextDecoder("utf-8", { fatal: false }).decode(bytes);
		if (!text || text.includes("\0")) return null;
		return text;
	} catch {
		return null;
	}
}
var DEFAULT_APPS = [
	{
		id: "youtube",
		name: "YouTube",
		on: true
	},
	{
		id: "zello",
		name: "Zello",
		on: true
	},
	{
		id: "grok",
		name: "Grok",
		on: true
	},
	{
		id: "browser",
		name: "Браузер",
		on: false
	},
	{
		id: "maps",
		name: "Карты",
		on: false
	},
	{
		id: "telegram",
		name: "Telegram",
		on: false
	}
];
var useProba = create()(persist((set, get) => ({
	profiles: [],
	activeId: null,
	selectedId: null,
	stamps: {},
	apps: DEFAULT_APPS,
	lastCheck: null,
	upsertProfile: (profile) => set((state) => {
		return {
			profiles: state.profiles.findIndex((item) => item.id === profile.id) >= 0 ? state.profiles.map((item) => item.id === profile.id ? profile : item) : [profile, ...state.profiles],
			activeId: profile.id
		};
	}),
	removeProfile: (id) => set((state) => {
		const profiles = state.profiles.filter((item) => item.id !== id);
		const active = state.activeId === id ? profiles[0]?.id ?? null : state.activeId;
		return {
			profiles,
			activeId: active,
			selectedId: profiles.find((item) => item.id === active)?.servers.some((server) => server.id === state.selectedId) ? state.selectedId : null
		};
	}),
	setActive: (id) => set((state) => {
		return {
			activeId: id,
			selectedId: state.profiles.find((item) => item.id === id)?.servers.some((server) => server.id === state.selectedId) ? state.selectedId : null
		};
	}),
	setSelected: (id) => set({ selectedId: id }),
	setLastCheck: (check) => set({ lastCheck: check }),
	pinToSelected: () => {
		const { selectedId, lastCheck, stamps } = get();
		if (!selectedId || !lastCheck) return;
		const by = (id) => lastCheck.samples.find((sample) => sample.id === id);
		const youtube = by("youtube");
		const zello = by("zello");
		const grok = by("grok");
		set({ stamps: {
			...stamps,
			[selectedId]: {
				at: lastCheck.at,
				youtubeMs: youtube?.latencyMs ?? null,
				zelloMs: zello?.latencyMs ?? null,
				grokMs: grok?.latencyMs ?? null,
				youtubeMbps: youtube?.mbps ?? null,
				zelloMbps: zello?.mbps ?? null,
				grokMbps: grok?.mbps ?? null
			}
		} });
	},
	toggleApp: (id) => set((state) => ({ apps: state.apps.map((app) => app.id === id ? {
		...app,
		on: !app.on
	} : app) }))
}), {
	name: "proba-v1",
	skipHydration: true,
	partialize: (state) => ({
		profiles: state.profiles,
		activeId: state.activeId,
		selectedId: state.selectedId,
		stamps: state.stamps,
		apps: state.apps,
		lastCheck: state.lastCheck
	})
}));
function AddSheet({ onClose }) {
	const upsert = useProba((state) => state.upsertProfile);
	const fetchSub = useServerFn(fetchSubscription);
	const [mode, setMode] = (0, import_react.useState)("link");
	const [link, setLink] = (0, import_react.useState)("");
	const [paste, setPaste] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [camera, setCamera] = (0, import_react.useState)(false);
	const fileRef = (0, import_react.useRef)(null);
	async function commit(body, source, name) {
		const servers = parseSubscription(body);
		if (!servers.length) throw new Error(/^\s*</.test(body) ? "Это страница, а не список серверов" : "В тексте нет серверов. Нужны vless, vmess, trojan, ss или Clash");
		upsert({
			id: crypto.randomUUID(),
			name: name.slice(0, 80),
			source,
			updatedAt: Date.now(),
			servers
		});
		onClose();
	}
	async function commitUrl(raw) {
		const unwrapped = unwrapSubUrl(raw);
		if (!/^https:\/\//i.test(unwrapped)) {
			if (/^(vless|vmess|trojan|ss|hy2|hysteria2):\/\//i.test(unwrapped) || unwrapped.includes("\n")) {
				await commit(raw, "paste", "Вставка");
				return;
			}
			throw new Error("Нужна ссылка https. Ссылки happ:// тоже подходят — внутри должна быть https");
		}
		const result = await fetchSub({ data: { url: unwrapped } });
		const servers = parseSubscription(result.body);
		if (!servers.length) throw new Error(/^\s*</.test(result.body) ? "Ссылка открыла страницу, а не подписку" : "В подписке нет серверов");
		let host = "Подписка";
		try {
			host = new URL(unwrapped).hostname.replace(/^www\./, "");
		} catch {}
		upsert({
			id: `url:${unwrapped}`,
			name: result.title || host,
			source: "url",
			url: unwrapped,
			updatedAt: Date.now(),
			servers,
			info: parseUserinfo(result.userinfo)
		});
		onClose();
	}
	async function onSubmit() {
		setError("");
		setBusy(true);
		try {
			if (mode === "link") await commitUrl(link);
			else await commit(paste, "paste", "Вставка");
		} catch (reason) {
			setError(errorText(reason));
		} finally {
			setBusy(false);
		}
	}
	async function onFile(file) {
		if (!file) return;
		setError("");
		setBusy(true);
		try {
			if (file.type.startsWith("image/")) {
				const text = await scanImage(file);
				if (!text) throw new Error("В картинке нет QR");
				await commitUrl(text);
				return;
			}
			await commit(await file.text(), "file", file.name.replace(/\.(txt|yaml|yml|json|conf)$/i, "") || "Файл");
		} catch (reason) {
			setError(errorText(reason));
		} finally {
			setBusy(false);
		}
	}
	async function fromClipboard() {
		setError("");
		try {
			const text = await navigator.clipboard.readText();
			if (mode === "link") setLink(text.trim());
			else setPaste(text);
		} catch {
			setError("Буфер недоступен — вставьте вручную");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-30 flex flex-col bg-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center justify-between px-4 pt-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-3xl italic text-paper",
					children: "Новая подписка"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onClose,
					className: "flex size-11 items-center justify-center rounded-full border border-line text-paper",
					"aria-label": "Закрыть",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-2 px-4 pt-4",
				children: [
					["link", "Ссылка"],
					["paste", "Текст"],
					["file", "Файл"]
				].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => {
						setMode(id);
						setError("");
						setCamera(false);
					},
					className: mode === id ? "min-h-11 flex-1 rounded-full bg-brass px-3 text-sm font-semibold text-brass-ink" : "min-h-11 flex-1 rounded-full border border-line px-3 text-sm text-paper",
					children: label
				}, id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-h-0 flex-1 flex-col gap-3 overflow-y-auto px-4 py-4",
				children: [
					mode === "link" && !camera && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-sm text-mute",
							htmlFor: "sub-url",
							children: "Ссылка подписки, happ:// или hiddify://"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "sub-url",
							value: link,
							onChange: (event) => setLink(event.target.value),
							placeholder: "https://",
							autoCapitalize: "off",
							autoCorrect: "off",
							spellCheck: false,
							className: "min-h-12 w-full rounded-card border border-line bg-panel px-4 text-paper outline-none focus:border-brass"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => void fromClipboard(),
								className: "flex min-h-11 flex-1 items-center justify-center gap-2 rounded-full border border-line text-sm text-paper",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipboardPaste, { className: "size-4" }), "Буфер"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setCamera(true),
								className: "flex min-h-11 flex-1 items-center justify-center gap-2 rounded-full border border-line text-sm text-paper",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QrCode, { className: "size-4" }), "QR"]
							})]
						})
					] }),
					mode === "link" && camera && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QrLive, {
						onText: (value) => {
							setCamera(false);
							setLink(value);
							setBusy(true);
							commitUrl(value).catch((reason) => setError(errorText(reason))).finally(() => setBusy(false));
						},
						onFail: (message) => {
							setCamera(false);
							setError(message);
						}
					}),
					mode === "paste" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-sm text-mute",
							htmlFor: "sub-paste",
							children: "Список ссылок или конфиг целиком"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							id: "sub-paste",
							value: paste,
							onChange: (event) => setPaste(event.target.value),
							className: "min-h-48 w-full flex-1 rounded-card border border-line bg-panel px-4 py-3 text-sm text-paper outline-none focus:border-brass",
							placeholder: "vless://…\nvmess://…",
							spellCheck: false
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => void fromClipboard(),
							className: "flex min-h-11 items-center justify-center gap-2 rounded-full border border-line text-sm text-paper",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipboardPaste, { className: "size-4" }), "Вставить из буфера"]
						})
					] }),
					mode === "file" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm leading-relaxed text-mute",
							children: "Текстовый файл подписки или снимок QR. Секреты узлов в список не попадают — только имя, протокол и адрес."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => fileRef.current?.click(),
							className: "flex min-h-24 flex-col items-center justify-center gap-2 rounded-card border border-dashed border-line bg-panel text-paper",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileUp, { className: "size-6 text-brass" }), "Выбрать файл"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							ref: fileRef,
							type: "file",
							accept: "text/plain,application/json,.txt,.yaml,.yml,.json,.conf,image/*",
							className: "hidden",
							onChange: (event) => void onFile(event.target.files?.[0])
						})
					] }),
					error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "rounded-card border border-line bg-panel px-4 py-3 text-sm text-paper",
						role: "alert",
						children: error
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm leading-relaxed text-mute",
						children: "Ссылка остаётся только в этом браузере. Чужие адреса и внутренние сети не запрашиваются."
					})
				]
			}),
			mode !== "file" && !camera && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "dock border-t border-line px-4 pt-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					disabled: busy || (mode === "link" ? link.trim().length < 8 : paste.trim().length < 8),
					onClick: () => void onSubmit(),
					className: "min-h-12 w-full rounded-full bg-brass text-base font-semibold text-brass-ink disabled:opacity-40",
					children: busy ? "Читаем…" : "Добавить"
				})
			})
		]
	});
}
function QrLive({ onText, onFail }) {
	const videoRef = (0, import_react.useRef)(null);
	const onTextRef = (0, import_react.useRef)(onText);
	const onFailRef = (0, import_react.useRef)(onFail);
	onTextRef.current = onText;
	onFailRef.current = onFail;
	(0, import_react.useEffect)(() => {
		const Detector = window.BarcodeDetector;
		if (!Detector || !navigator.mediaDevices?.getUserMedia) {
			onFailRef.current("Камера QR здесь недоступна. Вставьте ссылку или выберите снимок во вкладке «Файл».");
			return;
		}
		let stop = false;
		let stream = null;
		let timer = 0;
		const detector = new Detector({ formats: ["qr_code"] });
		(async () => {
			try {
				stream = await navigator.mediaDevices.getUserMedia({
					video: { facingMode: "environment" },
					audio: false
				});
				if (stop || !videoRef.current) return;
				videoRef.current.srcObject = stream;
				await videoRef.current.play();
				const tick = async () => {
					if (stop || !videoRef.current) return;
					try {
						const value = (await detector.detect(videoRef.current))[0]?.rawValue;
						if (value) {
							onTextRef.current(value);
							return;
						}
					} catch {}
					timer = window.setTimeout(() => void tick(), 400);
				};
				timer = window.setTimeout(() => void tick(), 400);
			} catch {
				if (!stop) onFailRef.current("Камера не разрешена. Можно вставить ссылку вручную.");
			}
		})();
		return () => {
			stop = true;
			window.clearTimeout(timer);
			stream?.getTracks().forEach((track) => track.stop());
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
			ref: videoRef,
			className: "aspect-square w-full rounded-card bg-panel object-cover",
			muted: true,
			playsInline: true
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-mute",
			children: "Наведите на QR подписки."
		})]
	});
}
async function scanImage(file) {
	const Detector = window.BarcodeDetector;
	if (!Detector) throw new Error("Этот браузер не читает QR с картинки. Вставьте ссылку текстом.");
	const bitmap = await createImageBitmap(file);
	try {
		return (await new Detector({ formats: ["qr_code"] }).detect(bitmap))[0]?.rawValue ?? null;
	} finally {
		bitmap.close();
	}
}
function errorText(error) {
	if (error instanceof Error && error.message) {
		const message = error.message.trim();
		if (message.startsWith("{")) try {
			const parsed = JSON.parse(message);
			if (parsed.message) return parsed.message;
		} catch {}
		return message.replace(/^Error:\s*/, "");
	}
	return "Не получилось прочитать подписку";
}
function formatMbps(value) {
	const digits = value >= 10 ? 0 : 1;
	return `${value.toFixed(digits)} Мбит/с`;
}
function formatMs(value) {
	return String(Math.max(1, Math.round(value)));
}
function grade(ms) {
	if (ms == null) return "нет ответа";
	if (ms < 120) return "ровно";
	if (ms < 280) return "нормально";
	if (ms < 600) return "туго";
	return "плохо";
}
function ticksFor(ms) {
	if (ms == null) return 0;
	if (ms < 80) return 6;
	if (ms < 140) return 5;
	if (ms < 220) return 4;
	if (ms < 350) return 3;
	if (ms < 600) return 2;
	return 1;
}
function countLabel(count) {
	const mod10 = count % 10;
	const mod100 = count % 100;
	if (mod10 === 1 && mod100 !== 11) return `${count} узел`;
	if (mod10 >= 2 && mod10 <= 4 && (mod100 < 12 || mod100 > 14)) return `${count} узла`;
	return `${count} узлов`;
}
function formatBytes(value) {
	if (!Number.isFinite(value) || value < 0) return "—";
	const units = [
		"Б",
		"КБ",
		"МБ",
		"ГБ",
		"ТБ"
	];
	let n = value;
	let i = 0;
	while (n >= 1024 && i < units.length - 1) {
		n /= 1024;
		i += 1;
	}
	const digits = n >= 10 || i === 0 ? 0 : 1;
	return `${n.toFixed(digits)} ${units[i]}`;
}
function formatWhen(at) {
	try {
		return new Intl.DateTimeFormat("ru-RU", {
			hour: "2-digit",
			minute: "2-digit",
			day: "numeric",
			month: "short"
		}).format(new Date(at));
	} catch {
		return "";
	}
}
function formatExpire(unix) {
	if (!unix) return "без срока";
	try {
		return new Intl.DateTimeFormat("ru-RU", {
			day: "numeric",
			month: "short",
			year: "numeric"
		}).format(/* @__PURE__ */ new Date(unix * 1e3));
	} catch {
		return "";
	}
}
var SERVICES = [
	{
		id: "youtube",
		label: "YouTube",
		hint: "видео"
	},
	{
		id: "zello",
		label: "Zello",
		hint: "рация"
	},
	{
		id: "grok",
		label: "Grok",
		hint: "чат"
	}
];
var PINGS = {
	youtube: "https://www.youtube.com/generate_204",
	zello: "https://zello.com/",
	grok: "https://grok.com/"
};
var FILES = {
	youtube: [
		"https://i.ytimg.com/vi/aqz-KE-bpKQ/hq720.jpg",
		"https://i.ytimg.com/vi/M7lc1UVf-VE/hq720.jpg",
		"https://i.ytimg.com/vi/9bZkp7q19f0/hq720.jpg",
		"https://i.ytimg.com/vi/dQw4w9WgXcQ/hq720.jpg"
	],
	zello: ["https://res.cloudinary.com/dd217rd0j/image/upload/w_2000/v1676495263/zellodotcom/ptt-ella.webp"],
	grok: ["https://media.x.ai/v1/website/grok-4-1-27413c83.webp"]
};
var MIN_BYTES = 6e4;
async function measureAll(signal) {
	return Promise.all(SERVICES.map((service) => measureOne(service.id, signal)));
}
async function measureOne(id, signal) {
	const meta = SERVICES.find((service) => service.id === id);
	const [latencyMs, flow] = await Promise.all([timePing(PINGS[id], signal), timeFiles(FILES[id], signal)]);
	let mbps = null;
	if (flow && flow.bytes >= MIN_BYTES && flow.ms >= 8) {
		mbps = flow.bytes * 8 / flow.ms / 1e3;
		if (!Number.isFinite(mbps) || mbps <= 0) mbps = null;
	}
	return {
		id,
		label: meta.label,
		hint: meta.hint,
		latencyMs,
		mbps
	};
}
async function timePing(url, parent) {
	const ctrl = new AbortController();
	const timer = setTimeout(() => ctrl.abort(), 8e3);
	const onAbort = () => ctrl.abort();
	parent?.addEventListener("abort", onAbort);
	const started = performance.now();
	try {
		await fetch(bust(url), {
			mode: "no-cors",
			cache: "no-store",
			redirect: "follow",
			referrerPolicy: "no-referrer",
			signal: ctrl.signal
		});
		return performance.now() - started;
	} catch {
		return null;
	} finally {
		clearTimeout(timer);
		parent?.removeEventListener("abort", onAbort);
	}
}
async function timeFiles(urls, parent) {
	const ctrl = new AbortController();
	const timer = setTimeout(() => ctrl.abort(), 14e3);
	const onAbort = () => ctrl.abort();
	parent?.addEventListener("abort", onAbort);
	const started = performance.now();
	try {
		const bytes = (await Promise.all(urls.map((url) => readBytes(bust(url), ctrl.signal)))).reduce((sum, n) => sum + n, 0);
		if (!bytes) return null;
		return {
			bytes,
			ms: performance.now() - started
		};
	} catch {
		return null;
	} finally {
		clearTimeout(timer);
		parent?.removeEventListener("abort", onAbort);
	}
}
async function readBytes(url, signal) {
	try {
		const res = await fetch(url, {
			mode: "cors",
			cache: "no-store",
			referrerPolicy: "no-referrer",
			signal
		});
		if (!res.ok) return 0;
		return (await res.arrayBuffer()).byteLength;
	} catch {
		return 0;
	}
}
function bust(url) {
	return `${url}${url.includes("?") ? "&" : "?"}proba=${Date.now()}`;
}
var ICONS = {
	youtube: Play,
	zello: Radio,
	grok: Sparkles
};
function ProbaApp() {
	const [tab, setTab] = (0, import_react.useState)("meter");
	const [sheet, setSheet] = (0, import_react.useState)(false);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [pinned, setPinned] = (0, import_react.useState)(false);
	const [sort, setSort] = (0, import_react.useState)("name");
	const [confirmId, setConfirmId] = (0, import_react.useState)(null);
	const [refreshing, setRefreshing] = (0, import_react.useState)(null);
	const [refreshError, setRefreshError] = (0, import_react.useState)("");
	const profiles = useProba((state) => state.profiles);
	const activeId = useProba((state) => state.activeId);
	const selectedId = useProba((state) => state.selectedId);
	const stamps = useProba((state) => state.stamps);
	const apps = useProba((state) => state.apps);
	const lastCheck = useProba((state) => state.lastCheck);
	const setActive = useProba((state) => state.setActive);
	const setSelected = useProba((state) => state.setSelected);
	const setLastCheck = useProba((state) => state.setLastCheck);
	const pinToSelected = useProba((state) => state.pinToSelected);
	const toggleApp = useProba((state) => state.toggleApp);
	const removeProfile = useProba((state) => state.removeProfile);
	const upsertProfile = useProba((state) => state.upsertProfile);
	const fetchSub = useServerFn(fetchSubscription);
	(0, import_react.useEffect)(() => {
		useProba.persist.rehydrate();
	}, []);
	const active = profiles.find((profile) => profile.id === activeId) ?? profiles[0] ?? null;
	const servers = active?.servers ?? [];
	const selected = servers.find((server) => server.id === selectedId) ?? null;
	const ordered = (0, import_react.useMemo)(() => {
		const list = [...servers];
		if (sort === "name") {
			list.sort((a, b) => a.name.localeCompare(b.name, "ru"));
			return list;
		}
		list.sort((a, b) => {
			return (stamps[a.id]?.youtubeMs ?? Number.POSITIVE_INFINITY) - (stamps[b.id]?.youtubeMs ?? Number.POSITIVE_INFINITY);
		});
		return list;
	}, [
		servers,
		sort,
		stamps
	]);
	const best = (0, import_react.useMemo)(() => {
		const ids = [
			"youtube",
			"zello",
			"grok"
		];
		const out = {};
		for (const id of ids) {
			let min = Number.POSITIVE_INFINITY;
			for (const stamp of Object.values(stamps)) {
				const value = id === "youtube" ? stamp.youtubeMs : id === "zello" ? stamp.zelloMs : stamp.grokMs;
				if (value != null && value < min) min = value;
			}
			if (Number.isFinite(min)) out[id] = min;
		}
		return out;
	}, [stamps]);
	async function runCheck() {
		setBusy(true);
		setPinned(false);
		try {
			const samples = await measureAll();
			setLastCheck({
				at: Date.now(),
				samples
			});
		} finally {
			setBusy(false);
		}
	}
	function pin() {
		if (!selected || !lastCheck) return;
		pinToSelected();
		setPinned(true);
	}
	async function refresh(id) {
		const profile = profiles.find((item) => item.id === id);
		if (!profile?.url) return;
		setRefreshError("");
		setRefreshing(id);
		try {
			const result = await fetchSub({ data: { url: profile.url } });
			const serversNext = parseSubscription(result.body);
			if (!serversNext.length) throw new Error("В обновлении нет серверов");
			upsertProfile({
				...profile,
				name: result.title || profile.name,
				updatedAt: Date.now(),
				servers: serversNext,
				info: parseUserinfo(result.userinfo) ?? profile.info
			});
		} catch (reason) {
			setRefreshError(reason instanceof Error ? reason.message : "Не удалось обновить");
		} finally {
			setRefreshing(null);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "min-h-dvh bg-ink text-paper",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex min-h-dvh w-full max-w-3xl flex-col px-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "flex items-end justify-between pt-5 pb-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-5xl leading-none italic text-paper",
							children: "Проба"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-3 h-px w-10 bg-brass" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "pt-2 text-sm tracking-wide text-mute",
							children: "три скорости"
						})
					] }), lastCheck && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "pb-1 text-sm text-mute",
						children: formatWhen(lastCheck.at)
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex-1 pb-28",
					children: [
						tab === "meter" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "flex flex-col gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid gap-3 md:grid-cols-3",
									children: [
										"youtube",
										"zello",
										"grok"
									].map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
										id,
										sample: lastCheck?.samples.find((item) => item.id === id) ?? null,
										busy
									}, id))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => void runCheck(),
									disabled: busy,
									className: "mt-2 min-h-12 rounded-full bg-brass text-base font-semibold text-brass-ink disabled:opacity-50",
									children: busy ? "Мерим…" : "Проверить"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: pin,
									disabled: !selected || !lastCheck || busy,
									className: "min-h-11 truncate rounded-full border border-line px-4 text-sm text-paper disabled:opacity-40",
									children: pinned ? "Закреплено" : selected ? `Закрепить за «${selected.name}»` : "Сначала выберите узел"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm leading-relaxed text-mute",
									children: "Цифры с этого телефона, по тому каналу, который включён сейчас. Отклик — до самого сайта. Поток — короткая загрузка его файлов, поэтому на быстром интернете мегабиты занижены. Чтобы сравнить узлы, переключите сервер в VPN и закрепите замер."
								})
							]
						}),
						tab === "nodes" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "flex flex-col gap-3",
							children: [!active && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
								title: "Нет узлов",
								text: "Добавьте подписку — ссылкой, текстом или файлом. Список разберётся сам.",
								action: "Добавить подписку",
								onAction: () => setSheet(true)
							}), active && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "truncate text-sm text-mute",
									children: [
										active.name,
										" · ",
										countLabel(servers.length)
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortChip, {
										on: sort === "name",
										onClick: () => setSort("name"),
										children: "Имя"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortChip, {
										on: sort === "delay",
										onClick: () => setSort("delay"),
										children: "YouTube"
									})]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "flex flex-col gap-2",
								children: ordered.map((server) => {
									const stamp = stamps[server.id];
									const on = server.id === selected?.id;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => setSelected(on ? null : server.id),
										className: on ? "w-full rounded-card border border-brass bg-panel px-4 py-3 text-left" : "w-full rounded-card border border-line bg-panel px-4 py-3 text-left",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "flex items-baseline justify-between gap-3",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "truncate font-medium text-paper",
													children: server.name
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "shrink-0 text-xs tracking-wide text-mute uppercase",
													children: server.protocol
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "mt-1 block truncate text-sm text-mute",
												children: [
													server.host,
													":",
													server.port
												]
											}),
											stamp && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StampRow, {
												stamp,
												best
											})
										]
									}) }, server.id);
								})
							})] })]
						}),
						tab === "profiles" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "flex flex-col gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => setSheet(true),
									className: "flex min-h-12 items-center justify-center gap-2 rounded-full bg-brass font-semibold text-brass-ink",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-5" }), "Добавить подписку"]
								}),
								refreshError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "rounded-card border border-line bg-panel px-4 py-3 text-sm",
									role: "alert",
									children: refreshError
								}),
								!profiles.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
									title: "Пока пусто",
									text: "Подойдёт ссылка обновления, набор vless/vmess, файл Clash или sing-box. QR можно снять камерой или картинкой."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "flex flex-col gap-2",
									children: profiles.map((profile) => {
										const used = (profile.info?.upload ?? 0) + (profile.info?.download ?? 0);
										const total = profile.info?.total ?? 0;
										const ratio = total > 0 ? Math.min(1, used / total) : 0;
										const on = profile.id === (active?.id ?? "");
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
											className: "rounded-card border border-line bg-panel px-4 py-3",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
													type: "button",
													onClick: () => setActive(profile.id),
													className: "w-full text-left",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "flex items-baseline justify-between gap-3",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "truncate font-medium",
															children: profile.name
														}), on && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-xs tracking-wide text-brass uppercase",
															children: "выбрана"
														})]
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "mt-1 block text-sm text-mute",
														children: [
															countLabel(profile.servers.length),
															" · ",
															formatWhen(profile.updatedAt)
														]
													})]
												}),
												total > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "mt-3",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "h-1 overflow-hidden rounded-full bg-line",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "h-full bg-brass",
															style: { width: `${Math.round(ratio * 100)}%` }
														})
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
														className: "pt-2 text-xs text-mute",
														children: [
															formatBytes(used),
															" из ",
															formatBytes(total),
															profile.info?.expire ? ` · до ${formatExpire(profile.info.expire)}` : ""
														]
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "mt-3 flex gap-2",
													children: [profile.url && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
														type: "button",
														onClick: () => void refresh(profile.id),
														disabled: refreshing === profile.id,
														className: "flex min-h-11 flex-1 items-center justify-center gap-2 rounded-full border border-line text-sm disabled:opacity-40",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "size-4" }), refreshing === profile.id ? "Обновляем" : "Обновить"]
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
														type: "button",
														onClick: () => {
															if (confirmId === profile.id) {
																removeProfile(profile.id);
																setConfirmId(null);
																return;
															}
															setConfirmId(profile.id);
														},
														className: "flex min-h-11 flex-1 items-center justify-center gap-2 rounded-full border border-line text-sm",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" }), confirmId === profile.id ? "Точно удалить" : "Удалить"]
													})]
												})
											]
										}, profile.id);
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-4 rounded-card border border-line bg-panel px-4 py-4",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
											className: "font-display text-2xl italic",
											children: "Через туннель"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "pt-1 pb-3 text-sm leading-relaxed text-mute",
											children: "Памятка, какие приложения гонять через прокси. На телефоне это включает ядро — здесь список только запоминается."
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
											className: "flex flex-col",
											children: apps.map((app) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
												className: "flex items-center justify-between gap-3 border-t border-line py-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: app.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													role: "switch",
													"aria-checked": app.on,
													onClick: () => toggleApp(app.id),
													className: app.on ? "flex h-8 w-14 items-center rounded-full bg-brass px-1" : "flex h-8 w-14 items-center rounded-full bg-line px-1",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: app.on ? "ml-auto size-6 rounded-full bg-brass-ink" : "size-6 rounded-full bg-paper" })
												})]
											}, app.id))
										})
									]
								})
							]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "dock fixed inset-x-0 bottom-0 z-20 border-t border-line bg-ink/95 backdrop-blur-md",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto grid max-w-3xl grid-cols-3 px-2 pt-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DockButton, {
							on: tab === "meter",
							onClick: () => setTab("meter"),
							icon: Gauge,
							label: "Замер"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DockButton, {
							on: tab === "nodes",
							onClick: () => setTab("nodes"),
							icon: Radio,
							label: "Узлы"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DockButton, {
							on: tab === "profiles",
							onClick: () => setTab("profiles"),
							icon: FolderOpen,
							label: "Профили"
						})
					]
				})
			}),
			sheet && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddSheet, { onClose: () => setSheet(false) })
		]
	});
}
function Meter({ id, sample, busy }) {
	const meta = {
		youtube: ["YouTube", "видео"],
		zello: ["Zello", "рация"],
		grok: ["Grok", "чат"]
	}[id];
	const Icon = ICONS[id];
	const ms = sample?.latencyMs ?? null;
	const filled = ticksFor(ms);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "rounded-card border border-line bg-panel px-4 py-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex items-center gap-2 text-sm tracking-wide text-mute uppercase",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4 text-brass" }), meta[0]]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: busy ? "live text-sm text-brass" : "text-sm text-mute",
					children: busy ? "мерим" : sample ? grade(ms) : meta[1]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display pt-3 text-6xl leading-none text-paper",
				children: busy || ms == null ? "—" : formatMs(ms)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "pt-2 text-sm text-mute",
				children: ms == null ? "мс · отклик" : "мс · отклик"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "pt-3 text-base text-paper",
				children: busy ? " " : sample?.mbps != null ? formatMbps(sample.mbps) : sample ? "поток не виден" : "ещё не мерили"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 flex gap-1",
				"aria-hidden": "true",
				children: Array.from({ length: 6 }, (_, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: index < filled && !busy ? "h-1 flex-1 rounded-full bg-brass" : "h-1 flex-1 rounded-full bg-line" }, index))
			})
		]
	});
}
function StampRow({ stamp, best }) {
	const cells = [
		[
			"YT",
			stamp.youtubeMs,
			stamp.youtubeMbps,
			"youtube"
		],
		[
			"Zello",
			stamp.zelloMs,
			stamp.zelloMbps,
			"zello"
		],
		[
			"Grok",
			stamp.grokMs,
			stamp.grokMbps,
			"grok"
		]
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "mt-3 grid grid-cols-3 gap-2",
		children: cells.map(([label, ms, mbps, id]) => {
			const mark = ms != null && best[id] != null && Math.round(ms) === Math.round(best[id]);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "min-w-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: mark ? "block text-xs text-brass" : "block text-xs text-mute",
						children: label
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block truncate text-sm text-paper",
						children: ms == null ? "—" : `${formatMs(ms)} мс`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block truncate text-xs text-mute",
						children: mbps == null ? "" : formatMbps(mbps)
					})
				]
			}, label);
		})
	});
}
function SortChip({ on, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		className: on ? "min-h-10 rounded-full bg-brass px-3 text-sm font-semibold text-brass-ink" : "min-h-10 rounded-full border border-line px-3 text-sm text-paper",
		children
	});
}
function DockButton({ on, onClick, icon: Icon, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		"aria-current": on ? "page" : void 0,
		className: "flex min-h-12 flex-col items-center justify-center gap-1 text-xs",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: on ? "size-5 text-brass" : "size-5 text-mute" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: on ? "text-paper" : "text-mute",
			children: label
		})]
	});
}
function Empty({ title, text, action, onAction }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-card border border-line bg-panel px-4 py-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-3xl italic",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "pt-2 text-sm leading-relaxed text-mute",
				children: text
			}),
			action && onAction && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: onAction,
				className: "mt-4 min-h-11 rounded-full bg-brass px-5 text-sm font-semibold text-brass-ink",
				children: action
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProbaApp, {});
}
//#endregion
export { Home as component };
