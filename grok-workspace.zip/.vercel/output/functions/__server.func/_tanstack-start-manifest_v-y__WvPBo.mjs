//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-y__WvPBo.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-C2n1B7cd.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-C2n1B7cd.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-B2BXPkqu.js"]
	}
} });
//#endregion
export { tsrStartManifest };
