import { createFileRoute } from "@tanstack/react-router";
import { ProbaApp } from "@/components/proba-app";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <ProbaApp />;
}
