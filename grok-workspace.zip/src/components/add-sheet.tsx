import { useEffect, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { ClipboardPaste, FileUp, QrCode, X } from "lucide-react";
import { fetchSubscription } from "@/lib/fetch-sub";
import { parseSubscription, parseUserinfo, unwrapSubUrl } from "@/lib/parse-sub";
import { useProba } from "@/lib/store";

type Mode = "link" | "paste" | "file";

type Detector = {
  detect: (source: CanvasImageSource) => Promise<Array<{ rawValue?: string }>>;
};

export function AddSheet({ onClose }: { onClose: () => void }) {
  const upsert = useProba((state) => state.upsertProfile);
  const fetchSub = useServerFn(fetchSubscription);
  const [mode, setMode] = useState<Mode>("link");
  const [link, setLink] = useState("");
  const [paste, setPaste] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [camera, setCamera] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  async function commit(body: string, source: "paste" | "file", name: string) {
    const servers = parseSubscription(body);
    if (!servers.length) {
      throw new Error(
        /^\s*</.test(body)
          ? "Это страница, а не список серверов"
          : "В тексте нет серверов. Нужны vless, vmess, trojan, ss или Clash",
      );
    }
    upsert({
      id: crypto.randomUUID(),
      name: name.slice(0, 80),
      source,
      updatedAt: Date.now(),
      servers,
    });
    onClose();
  }

  async function commitUrl(raw: string) {
    const unwrapped = unwrapSubUrl(raw);
    if (!/^https:\/\//i.test(unwrapped)) {
      if (/^(vless|vmess|trojan|ss|hy2|hysteria2):\/\//i.test(unwrapped) || unwrapped.includes("\n")) {
        await commit(raw, "paste", "Вставка");
        return;
      }
      throw new Error("Нужна ссылка https. Ссылки happ:// тоже подходят — внутри должна быть https");
    }
    const result = await fetchSub({ data: { url: unwrapped } });
    const servers = parseSubscription(result.body);
    if (!servers.length) {
      throw new Error(
        /^\s*</.test(result.body)
          ? "Ссылка открыла страницу, а не подписку"
          : "В подписке нет серверов",
      );
    }
    let host = "Подписка";
    try {
      host = new URL(unwrapped).hostname.replace(/^www\./, "");
    } catch {
      /* keep */
    }
    upsert({
      id: `url:${unwrapped}`,
      name: result.title || host,
      source: "url",
      url: unwrapped,
      updatedAt: Date.now(),
      servers,
      info: parseUserinfo(result.userinfo),
    });
    onClose();
  }

  async function onSubmit() {
    setError("");
    setBusy(true);
    try {
      if (mode === "link") await commitUrl(link);
      else await commit(paste, "paste", "Вставка");
    } catch (reason) {
      setError(errorText(reason));
    } finally {
      setBusy(false);
    }
  }

  async function onFile(file: File | undefined) {
    if (!file) return;
    setError("");
    setBusy(true);
    try {
      if (file.type.startsWith("image/")) {
        const text = await scanImage(file);
        if (!text) throw new Error("В картинке нет QR");
        await commitUrl(text);
        return;
      }
      const text = await file.text();
      const base = file.name.replace(/\.(txt|yaml|yml|json|conf)$/i, "") || "Файл";
      await commit(text, "file", base);
    } catch (reason) {
      setError(errorText(reason));
    } finally {
      setBusy(false);
    }
  }

  async function fromClipboard() {
    setError("");
    try {
      const text = await navigator.clipboard.readText();
      if (mode === "link") setLink(text.trim());
      else setPaste(text);
    } catch {
      setError("Буфер недоступен — вставьте вручную");
    }
  }

  return (
    <div className="fixed inset-0 z-30 flex flex-col bg-ink">
      <header className="flex items-center justify-between px-4 pt-4">
        <h2 className="font-display text-3xl italic text-paper">Новая подписка</h2>
        <button
          type="button"
          onClick={onClose}
          className="flex size-11 items-center justify-center rounded-full border border-line text-paper"
          aria-label="Закрыть"
        >
          <X className="size-5" />
        </button>
      </header>
      <div className="flex gap-2 px-4 pt-4">
        {(
          [
            ["link", "Ссылка"],
            ["paste", "Текст"],
            ["file", "Файл"],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            type="button"
            onClick={() => {
              setMode(id);
              setError("");
              setCamera(false);
            }}
            className={
              mode === id
                ? "min-h-11 flex-1 rounded-full bg-brass px-3 text-sm font-semibold text-brass-ink"
                : "min-h-11 flex-1 rounded-full border border-line px-3 text-sm text-paper"
            }
          >
            {label}
          </button>
        ))}
      </div>
      <div className="flex min-h-0 flex-1 flex-col gap-3 overflow-y-auto px-4 py-4">
        {mode === "link" && !camera && (
          <>
            <label className="text-sm text-mute" htmlFor="sub-url">
              Ссылка подписки, happ:// или hiddify://
            </label>
            <input
              id="sub-url"
              value={link}
              onChange={(event) => setLink(event.target.value)}
              placeholder="https://"
              autoCapitalize="off"
              autoCorrect="off"
              spellCheck={false}
              className="min-h-12 w-full rounded-card border border-line bg-panel px-4 text-paper outline-none focus:border-brass"
            />
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => void fromClipboard()}
                className="flex min-h-11 flex-1 items-center justify-center gap-2 rounded-full border border-line text-sm text-paper"
              >
                <ClipboardPaste className="size-4" />
                Буфер
              </button>
              <button
                type="button"
                onClick={() => setCamera(true)}
                className="flex min-h-11 flex-1 items-center justify-center gap-2 rounded-full border border-line text-sm text-paper"
              >
                <QrCode className="size-4" />
                QR
              </button>
            </div>
          </>
        )}
        {mode === "link" && camera && (
          <QrLive
            onText={(value) => {
              setCamera(false);
              setLink(value);
              setBusy(true);
              void commitUrl(value)
                .catch((reason) => setError(errorText(reason)))
                .finally(() => setBusy(false));
            }}
            onFail={(message) => {
              setCamera(false);
              setError(message);
            }}
          />
        )}
        {mode === "paste" && (
          <>
            <label className="text-sm text-mute" htmlFor="sub-paste">
              Список ссылок или конфиг целиком
            </label>
            <textarea
              id="sub-paste"
              value={paste}
              onChange={(event) => setPaste(event.target.value)}
              className="min-h-48 w-full flex-1 rounded-card border border-line bg-panel px-4 py-3 text-sm text-paper outline-none focus:border-brass"
              placeholder={"vless://…\nvmess://…"}
              spellCheck={false}
            />
            <button
              type="button"
              onClick={() => void fromClipboard()}
              className="flex min-h-11 items-center justify-center gap-2 rounded-full border border-line text-sm text-paper"
            >
              <ClipboardPaste className="size-4" />
              Вставить из буфера
            </button>
          </>
        )}
        {mode === "file" && (
          <>
            <p className="text-sm leading-relaxed text-mute">
              Текстовый файл подписки или снимок QR. Секреты узлов в список не попадают — только имя, протокол и адрес.
            </p>
            <button
              type="button"
              onClick={() => fileRef.current?.click()}
              className="flex min-h-24 flex-col items-center justify-center gap-2 rounded-card border border-dashed border-line bg-panel text-paper"
            >
              <FileUp className="size-6 text-brass" />
              Выбрать файл
            </button>
            <input
              ref={fileRef}
              type="file"
              accept="text/plain,application/json,.txt,.yaml,.yml,.json,.conf,image/*"
              className="hidden"
              onChange={(event) => void onFile(event.target.files?.[0])}
            />
          </>
        )}
        {error && (
          <p className="rounded-card border border-line bg-panel px-4 py-3 text-sm text-paper" role="alert">
            {error}
          </p>
        )}
        <p className="text-sm leading-relaxed text-mute">
          Ссылка остаётся только в этом браузере. Чужие адреса и внутренние сети не запрашиваются.
        </p>
      </div>
      {mode !== "file" && !camera && (
        <div className="dock border-t border-line px-4 pt-3">
          <button
            type="button"
            disabled={busy || (mode === "link" ? link.trim().length < 8 : paste.trim().length < 8)}
            onClick={() => void onSubmit()}
            className="min-h-12 w-full rounded-full bg-brass text-base font-semibold text-brass-ink disabled:opacity-40"
          >
            {busy ? "Читаем…" : "Добавить"}
          </button>
        </div>
      )}
    </div>
  );
}

function QrLive({ onText, onFail }: { onText: (value: string) => void; onFail: (message: string) => void }) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const onTextRef = useRef(onText);
  const onFailRef = useRef(onFail);
  onTextRef.current = onText;
  onFailRef.current = onFail;
  useEffect(() => {
    const Detector = (
      window as unknown as {
        BarcodeDetector?: new (opts: { formats: string[] }) => Detector;
      }
    ).BarcodeDetector;
    if (!Detector || !navigator.mediaDevices?.getUserMedia) {
      onFailRef.current("Камера QR здесь недоступна. Вставьте ссылку или выберите снимок во вкладке «Файл».");
      return;
    }
    let stop = false;
    let stream: MediaStream | null = null;
    let timer = 0;
    const detector = new Detector({ formats: ["qr_code"] });
    void (async () => {
      try {
        stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: "environment" },
          audio: false,
        });
        if (stop || !videoRef.current) return;
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
        const tick = async () => {
          if (stop || !videoRef.current) return;
          try {
            const codes = await detector.detect(videoRef.current);
            const value = codes[0]?.rawValue;
            if (value) {
              onTextRef.current(value);
              return;
            }
          } catch {
            /* frame not ready */
          }
          timer = window.setTimeout(() => void tick(), 400);
        };
        timer = window.setTimeout(() => void tick(), 400);
      } catch {
        if (!stop) onFailRef.current("Камера не разрешена. Можно вставить ссылку вручную.");
      }
    })();
    return () => {
      stop = true;
      window.clearTimeout(timer);
      stream?.getTracks().forEach((track) => track.stop());
    };
  }, []);

  return (
    <div className="flex flex-col gap-3">
      <video ref={videoRef} className="aspect-square w-full rounded-card bg-panel object-cover" muted playsInline />
      <p className="text-sm text-mute">Наведите на QR подписки.</p>
    </div>
  );
}

async function scanImage(file: File): Promise<string | null> {
  const Detector = (
    window as unknown as {
      BarcodeDetector?: new (opts: { formats: string[] }) => Detector;
    }
  ).BarcodeDetector;
  if (!Detector) throw new Error("Этот браузер не читает QR с картинки. Вставьте ссылку текстом.");
  const bitmap = await createImageBitmap(file);
  try {
    const codes = await new Detector({ formats: ["qr_code"] }).detect(bitmap);
    return codes[0]?.rawValue ?? null;
  } finally {
    bitmap.close();
  }
}

function errorText(error: unknown): string {
  if (error instanceof Error && error.message) {
    const message = error.message.trim();
    if (message.startsWith("{")) {
      try {
        const parsed = JSON.parse(message) as { message?: string };
        if (parsed.message) return parsed.message;
      } catch {
        /* keep */
      }
    }
    return message.replace(/^Error:\s*/, "");
  }
  return "Не получилось прочитать подписку";
}
