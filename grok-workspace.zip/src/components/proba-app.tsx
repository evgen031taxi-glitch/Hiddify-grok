import { useEffect, useMemo, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { FolderOpen, Gauge, Play, Plus, Radio, RefreshCw, Sparkles, Trash2 } from "lucide-react";
import { AddSheet } from "@/components/add-sheet";
import { fetchSubscription } from "@/lib/fetch-sub";
import { formatBytes, formatExpire, formatMbps, formatMs, formatWhen, grade, ticksFor, countLabel } from "@/lib/format";
import { parseSubscription, parseUserinfo } from "@/lib/parse-sub";
import { measureAll, type Sample, type ServiceId } from "@/lib/probe";
import { useProba, type Stamp } from "@/lib/store";

type Tab = "meter" | "nodes" | "profiles";

const ICONS: Record<ServiceId, typeof Play> = {
  youtube: Play,
  zello: Radio,
  grok: Sparkles,
};

export function ProbaApp() {
  const [tab, setTab] = useState<Tab>("meter");
  const [sheet, setSheet] = useState(false);
  const [busy, setBusy] = useState(false);
  const [pinned, setPinned] = useState(false);
  const [sort, setSort] = useState<"name" | "delay">("name");
  const [confirmId, setConfirmId] = useState<string | null>(null);
  const [refreshing, setRefreshing] = useState<string | null>(null);
  const [refreshError, setRefreshError] = useState("");

  const profiles = useProba((state) => state.profiles);
  const activeId = useProba((state) => state.activeId);
  const selectedId = useProba((state) => state.selectedId);
  const stamps = useProba((state) => state.stamps);
  const apps = useProba((state) => state.apps);
  const lastCheck = useProba((state) => state.lastCheck);
  const setActive = useProba((state) => state.setActive);
  const setSelected = useProba((state) => state.setSelected);
  const setLastCheck = useProba((state) => state.setLastCheck);
  const pinToSelected = useProba((state) => state.pinToSelected);
  const toggleApp = useProba((state) => state.toggleApp);
  const removeProfile = useProba((state) => state.removeProfile);
  const upsertProfile = useProba((state) => state.upsertProfile);
  const fetchSub = useServerFn(fetchSubscription);

  useEffect(() => {
    void useProba.persist.rehydrate();
  }, []);

  const active = profiles.find((profile) => profile.id === activeId) ?? profiles[0] ?? null;
  const servers = active?.servers ?? [];
  const selected = servers.find((server) => server.id === selectedId) ?? null;

  const ordered = useMemo(() => {
    const list = [...servers];
    if (sort === "name") {
      list.sort((a, b) => a.name.localeCompare(b.name, "ru"));
      return list;
    }
    list.sort((a, b) => {
      const left = stamps[a.id]?.youtubeMs ?? Number.POSITIVE_INFINITY;
      const right = stamps[b.id]?.youtubeMs ?? Number.POSITIVE_INFINITY;
      return left - right;
    });
    return list;
  }, [servers, sort, stamps]);

  const best = useMemo(() => {
    const ids: ServiceId[] = ["youtube", "zello", "grok"];
    const out: Partial<Record<ServiceId, number>> = {};
    for (const id of ids) {
      let min = Number.POSITIVE_INFINITY;
      for (const stamp of Object.values(stamps)) {
        const value = id === "youtube" ? stamp.youtubeMs : id === "zello" ? stamp.zelloMs : stamp.grokMs;
        if (value != null && value < min) min = value;
      }
      if (Number.isFinite(min)) out[id] = min;
    }
    return out;
  }, [stamps]);

  async function runCheck() {
    setBusy(true);
    setPinned(false);
    try {
      const samples = await measureAll();
      setLastCheck({ at: Date.now(), samples });
    } finally {
      setBusy(false);
    }
  }

  function pin() {
    if (!selected || !lastCheck) return;
    pinToSelected();
    setPinned(true);
  }

  async function refresh(id: string) {
    const profile = profiles.find((item) => item.id === id);
    if (!profile?.url) return;
    setRefreshError("");
    setRefreshing(id);
    try {
      const result = await fetchSub({ data: { url: profile.url } });
      const serversNext = parseSubscription(result.body);
      if (!serversNext.length) throw new Error("В обновлении нет серверов");
      upsertProfile({
        ...profile,
        name: result.title || profile.name,
        updatedAt: Date.now(),
        servers: serversNext,
        info: parseUserinfo(result.userinfo) ?? profile.info,
      });
    } catch (reason) {
      setRefreshError(reason instanceof Error ? reason.message : "Не удалось обновить");
    } finally {
      setRefreshing(null);
    }
  }

  return (
    <main className="min-h-dvh bg-ink text-paper">
      <div className="mx-auto flex min-h-dvh w-full max-w-3xl flex-col px-4">
        <header className="flex items-end justify-between pt-5 pb-4">
          <div>
            <p className="font-display text-5xl leading-none italic text-paper">Проба</p>
            <div className="mt-3 h-px w-10 bg-brass" />
            <p className="pt-2 text-sm tracking-wide text-mute">три скорости</p>
          </div>
          {lastCheck && <p className="pb-1 text-sm text-mute">{formatWhen(lastCheck.at)}</p>}
        </header>

        <div className="flex-1 pb-28">
          {tab === "meter" && (
            <section className="flex flex-col gap-3">
              <div className="grid gap-3 md:grid-cols-3">
                {(["youtube", "zello", "grok"] as const).map((id) => (
                  <Meter
                    key={id}
                    id={id}
                    sample={lastCheck?.samples.find((item) => item.id === id) ?? null}
                    busy={busy}
                  />
                ))}
              </div>
              <button
                type="button"
                onClick={() => void runCheck()}
                disabled={busy}
                className="mt-2 min-h-12 rounded-full bg-brass text-base font-semibold text-brass-ink disabled:opacity-50"
              >
                {busy ? "Мерим…" : "Проверить"}
              </button>
              <button
                type="button"
                onClick={pin}
                disabled={!selected || !lastCheck || busy}
                className="min-h-11 truncate rounded-full border border-line px-4 text-sm text-paper disabled:opacity-40"
              >
                {pinned
                  ? "Закреплено"
                  : selected
                    ? `Закрепить за «${selected.name}»`
                    : "Сначала выберите узел"}
              </button>
              <p className="text-sm leading-relaxed text-mute">
                Цифры с этого телефона, по тому каналу, который включён сейчас. Отклик — до самого сайта.
                Поток — короткая загрузка его файлов, поэтому на быстром интернете мегабиты занижены. Чтобы
                сравнить узлы, переключите сервер в VPN и закрепите замер.
              </p>
            </section>
          )}

          {tab === "nodes" && (
            <section className="flex flex-col gap-3">
              {!active && (
                <Empty
                  title="Нет узлов"
                  text="Добавьте подписку — ссылкой, текстом или файлом. Список разберётся сам."
                  action="Добавить подписку"
                  onAction={() => setSheet(true)}
                />
              )}
              {active && (
                <>
                  <div className="flex items-center justify-between gap-3">
                    <p className="truncate text-sm text-mute">
                      {active.name} · {countLabel(servers.length)}
                    </p>
                    <div className="flex gap-2">
                      <SortChip on={sort === "name"} onClick={() => setSort("name")}>
                        Имя
                      </SortChip>
                      <SortChip on={sort === "delay"} onClick={() => setSort("delay")}>
                        YouTube
                      </SortChip>
                    </div>
                  </div>
                  <ul className="flex flex-col gap-2">
                    {ordered.map((server) => {
                      const stamp = stamps[server.id];
                      const on = server.id === selected?.id;
                      return (
                        <li key={server.id}>
                          <button
                            type="button"
                            onClick={() => setSelected(on ? null : server.id)}
                            className={
                              on
                                ? "w-full rounded-card border border-brass bg-panel px-4 py-3 text-left"
                                : "w-full rounded-card border border-line bg-panel px-4 py-3 text-left"
                            }
                          >
                            <span className="flex items-baseline justify-between gap-3">
                              <span className="truncate font-medium text-paper">{server.name}</span>
                              <span className="shrink-0 text-xs tracking-wide text-mute uppercase">
                                {server.protocol}
                              </span>
                            </span>
                            <span className="mt-1 block truncate text-sm text-mute">
                              {server.host}:{server.port}
                            </span>
                            {stamp && <StampRow stamp={stamp} best={best} />}
                          </button>
                        </li>
                      );
                    })}
                  </ul>
                </>
              )}
            </section>
          )}

          {tab === "profiles" && (
            <section className="flex flex-col gap-3">
              <button
                type="button"
                onClick={() => setSheet(true)}
                className="flex min-h-12 items-center justify-center gap-2 rounded-full bg-brass font-semibold text-brass-ink"
              >
                <Plus className="size-5" />
                Добавить подписку
              </button>
              {refreshError && (
                <p className="rounded-card border border-line bg-panel px-4 py-3 text-sm" role="alert">
                  {refreshError}
                </p>
              )}
              {!profiles.length && (
                <Empty
                  title="Пока пусто"
                  text="Подойдёт ссылка обновления, набор vless/vmess, файл Clash или sing-box. QR можно снять камерой или картинкой."
                />
              )}
              <ul className="flex flex-col gap-2">
                {profiles.map((profile) => {
                  const used = (profile.info?.upload ?? 0) + (profile.info?.download ?? 0);
                  const total = profile.info?.total ?? 0;
                  const ratio = total > 0 ? Math.min(1, used / total) : 0;
                  const on = profile.id === (active?.id ?? "");
                  return (
                    <li key={profile.id} className="rounded-card border border-line bg-panel px-4 py-3">
                      <button type="button" onClick={() => setActive(profile.id)} className="w-full text-left">
                        <span className="flex items-baseline justify-between gap-3">
                          <span className="truncate font-medium">{profile.name}</span>
                          {on && <span className="text-xs tracking-wide text-brass uppercase">выбрана</span>}
                        </span>
                        <span className="mt-1 block text-sm text-mute">
                          {countLabel(profile.servers.length)} · {formatWhen(profile.updatedAt)}
                        </span>
                      </button>
                      {total > 0 && (
                        <div className="mt-3">
                          <div className="h-1 overflow-hidden rounded-full bg-line">
                            <div className="h-full bg-brass" style={{ width: `${Math.round(ratio * 100)}%` }} />
                          </div>
                          <p className="pt-2 text-xs text-mute">
                            {formatBytes(used)} из {formatBytes(total)}
                            {profile.info?.expire ? ` · до ${formatExpire(profile.info.expire)}` : ""}
                          </p>
                        </div>
                      )}
                      <div className="mt-3 flex gap-2">
                        {profile.url && (
                          <button
                            type="button"
                            onClick={() => void refresh(profile.id)}
                            disabled={refreshing === profile.id}
                            className="flex min-h-11 flex-1 items-center justify-center gap-2 rounded-full border border-line text-sm disabled:opacity-40"
                          >
                            <RefreshCw className="size-4" />
                            {refreshing === profile.id ? "Обновляем" : "Обновить"}
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => {
                            if (confirmId === profile.id) {
                              removeProfile(profile.id);
                              setConfirmId(null);
                              return;
                            }
                            setConfirmId(profile.id);
                          }}
                          className="flex min-h-11 flex-1 items-center justify-center gap-2 rounded-full border border-line text-sm"
                        >
                          <Trash2 className="size-4" />
                          {confirmId === profile.id ? "Точно удалить" : "Удалить"}
                        </button>
                      </div>
                    </li>
                  );
                })}
              </ul>

              <div className="mt-4 rounded-card border border-line bg-panel px-4 py-4">
                <h2 className="font-display text-2xl italic">Через туннель</h2>
                <p className="pt-1 pb-3 text-sm leading-relaxed text-mute">
                  Памятка, какие приложения гонять через прокси. На телефоне это включает ядро — здесь список только
                  запоминается.
                </p>
                <ul className="flex flex-col">
                  {apps.map((app) => (
                    <li key={app.id} className="flex items-center justify-between gap-3 border-t border-line py-2">
                      <span>{app.name}</span>
                      <button
                        type="button"
                        role="switch"
                        aria-checked={app.on}
                        onClick={() => toggleApp(app.id)}
                        className={
                          app.on
                            ? "flex h-8 w-14 items-center rounded-full bg-brass px-1"
                            : "flex h-8 w-14 items-center rounded-full bg-line px-1"
                        }
                      >
                        <span
                          className={
                            app.on
                              ? "ml-auto size-6 rounded-full bg-brass-ink"
                              : "size-6 rounded-full bg-paper"
                          }
                        />
                      </button>
                    </li>
                  ))}
                </ul>
              </div>
            </section>
          )}
        </div>
      </div>

      <nav className="dock fixed inset-x-0 bottom-0 z-20 border-t border-line bg-ink/95 backdrop-blur-md">
        <div className="mx-auto grid max-w-3xl grid-cols-3 px-2 pt-2">
          <DockButton on={tab === "meter"} onClick={() => setTab("meter")} icon={Gauge} label="Замер" />
          <DockButton on={tab === "nodes"} onClick={() => setTab("nodes")} icon={Radio} label="Узлы" />
          <DockButton
            on={tab === "profiles"}
            onClick={() => setTab("profiles")}
            icon={FolderOpen}
            label="Профили"
          />
        </div>
      </nav>
      {sheet && <AddSheet onClose={() => setSheet(false)} />}
    </main>
  );
}

function Meter({ id, sample, busy }: { id: ServiceId; sample: Sample | null; busy: boolean }) {
  const meta = { youtube: ["YouTube", "видео"], zello: ["Zello", "рация"], grok: ["Grok", "чат"] }[id];
  const Icon = ICONS[id];
  const ms = sample?.latencyMs ?? null;
  const filled = ticksFor(ms);
  return (
    <article className="rounded-card border border-line bg-panel px-4 py-4">
      <div className="flex items-center justify-between gap-3">
        <span className="flex items-center gap-2 text-sm tracking-wide text-mute uppercase">
          <Icon className="size-4 text-brass" />
          {meta[0]}
        </span>
        <span className={busy ? "live text-sm text-brass" : "text-sm text-mute"}>
          {busy ? "мерим" : sample ? grade(ms) : meta[1]}
        </span>
      </div>
      <p className="font-display pt-3 text-6xl leading-none text-paper">{busy || ms == null ? "—" : formatMs(ms)}</p>
      <p className="pt-2 text-sm text-mute">{ms == null ? "мс · отклик" : "мс · отклик"}</p>
      <p className="pt-3 text-base text-paper">
        {busy ? " " : sample?.mbps != null ? formatMbps(sample.mbps) : sample ? "поток не виден" : "ещё не мерили"}
      </p>
      <div className="mt-4 flex gap-1" aria-hidden="true">
        {Array.from({ length: 6 }, (_, index) => (
          <span
            key={index}
            className={index < filled && !busy ? "h-1 flex-1 rounded-full bg-brass" : "h-1 flex-1 rounded-full bg-line"}
          />
        ))}
      </div>
    </article>
  );
}

function StampRow({ stamp, best }: { stamp: Stamp; best: Partial<Record<ServiceId, number>> }) {
  const cells: Array<[string, number | null, number | null, ServiceId]> = [
    ["YT", stamp.youtubeMs, stamp.youtubeMbps, "youtube"],
    ["Zello", stamp.zelloMs, stamp.zelloMbps, "zello"],
    ["Grok", stamp.grokMs, stamp.grokMbps, "grok"],
  ];
  return (
    <span className="mt-3 grid grid-cols-3 gap-2">
      {cells.map(([label, ms, mbps, id]) => {
        const mark = ms != null && best[id] != null && Math.round(ms) === Math.round(best[id]);
        return (
          <span key={label} className="min-w-0">
            <span className={mark ? "block text-xs text-brass" : "block text-xs text-mute"}>{label}</span>
            <span className="block truncate text-sm text-paper">{ms == null ? "—" : `${formatMs(ms)} мс`}</span>
            <span className="block truncate text-xs text-mute">{mbps == null ? "" : formatMbps(mbps)}</span>
          </span>
        );
      })}
    </span>
  );
}

function SortChip({
  on,
  onClick,
  children,
}: {
  on: boolean;
  onClick: () => void;
  children: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={
        on
          ? "min-h-10 rounded-full bg-brass px-3 text-sm font-semibold text-brass-ink"
          : "min-h-10 rounded-full border border-line px-3 text-sm text-paper"
      }
    >
      {children}
    </button>
  );
}

function DockButton({
  on,
  onClick,
  icon: Icon,
  label,
}: {
  on: boolean;
  onClick: () => void;
  icon: typeof Gauge;
  label: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-current={on ? "page" : undefined}
      className="flex min-h-12 flex-col items-center justify-center gap-1 text-xs"
    >
      <Icon className={on ? "size-5 text-brass" : "size-5 text-mute"} />
      <span className={on ? "text-paper" : "text-mute"}>{label}</span>
    </button>
  );
}

function Empty({
  title,
  text,
  action,
  onAction,
}: {
  title: string;
  text: string;
  action?: string;
  onAction?: () => void;
}) {
  return (
    <div className="rounded-card border border-line bg-panel px-4 py-6">
      <h2 className="font-display text-3xl italic">{title}</h2>
      <p className="pt-2 text-sm leading-relaxed text-mute">{text}</p>
      {action && onAction && (
        <button
          type="button"
          onClick={onAction}
          className="mt-4 min-h-11 rounded-full bg-brass px-5 text-sm font-semibold text-brass-ink"
        >
          {action}
        </button>
      )}
    </div>
  );
}
