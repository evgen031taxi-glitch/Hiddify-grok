export type ServiceId = "youtube" | "zello" | "grok";

export type Sample = {
  id: ServiceId;
  label: string;
  hint: string;
  latencyMs: number | null;
  mbps: number | null;
};

export const SERVICES: Array<{ id: ServiceId; label: string; hint: string }> = [
  { id: "youtube", label: "YouTube", hint: "видео" },
  { id: "zello", label: "Zello", hint: "рация" },
  { id: "grok", label: "Grok", hint: "чат" },
];

const PINGS: Record<ServiceId, string> = {
  youtube: "https://www.youtube.com/generate_204",
  zello: "https://zello.com/",
  grok: "https://grok.com/",
};

const FILES: Record<ServiceId, string[]> = {
  youtube: [
    "https://i.ytimg.com/vi/aqz-KE-bpKQ/hq720.jpg",
    "https://i.ytimg.com/vi/M7lc1UVf-VE/hq720.jpg",
    "https://i.ytimg.com/vi/9bZkp7q19f0/hq720.jpg",
    "https://i.ytimg.com/vi/dQw4w9WgXcQ/hq720.jpg",
  ],
  zello: ["https://res.cloudinary.com/dd217rd0j/image/upload/w_2000/v1676495263/zellodotcom/ptt-ella.webp"],
  grok: ["https://media.x.ai/v1/website/grok-4-1-27413c83.webp"],
};

const MIN_BYTES = 60_000;

export async function measureAll(signal?: AbortSignal): Promise<Sample[]> {
  return Promise.all(SERVICES.map((service) => measureOne(service.id, signal)));
}

async function measureOne(id: ServiceId, signal?: AbortSignal): Promise<Sample> {
  const meta = SERVICES.find((service) => service.id === id)!;
  const [latencyMs, flow] = await Promise.all([
    timePing(PINGS[id], signal),
    timeFiles(FILES[id], signal),
  ]);
  let mbps: number | null = null;
  if (flow && flow.bytes >= MIN_BYTES && flow.ms >= 8) {
    mbps = (flow.bytes * 8) / flow.ms / 1000;
    if (!Number.isFinite(mbps) || mbps <= 0) mbps = null;
  }
  return {
    id,
    label: meta.label,
    hint: meta.hint,
    latencyMs,
    mbps,
  };
}

async function timePing(url: string, parent?: AbortSignal): Promise<number | null> {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 8000);
  const onAbort = () => ctrl.abort();
  parent?.addEventListener("abort", onAbort);
  const started = performance.now();
  try {
    await fetch(bust(url), {
      mode: "no-cors",
      cache: "no-store",
      redirect: "follow",
      referrerPolicy: "no-referrer",
      signal: ctrl.signal,
    });
    return performance.now() - started;
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
    parent?.removeEventListener("abort", onAbort);
  }
}

async function timeFiles(
  urls: string[],
  parent?: AbortSignal,
): Promise<{ bytes: number; ms: number } | null> {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 14000);
  const onAbort = () => ctrl.abort();
  parent?.addEventListener("abort", onAbort);
  const started = performance.now();
  try {
    const parts = await Promise.all(urls.map((url) => readBytes(bust(url), ctrl.signal)));
    const bytes = parts.reduce((sum, n) => sum + n, 0);
    if (!bytes) return null;
    return { bytes, ms: performance.now() - started };
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
    parent?.removeEventListener("abort", onAbort);
  }
}

async function readBytes(url: string, signal: AbortSignal): Promise<number> {
  try {
    const res = await fetch(url, {
      mode: "cors",
      cache: "no-store",
      referrerPolicy: "no-referrer",
      signal,
    });
    if (!res.ok) return 0;
    const buf = await res.arrayBuffer();
    return buf.byteLength;
  } catch {
    return 0;
  }
}

function bust(url: string): string {
  const join = url.includes("?") ? "&" : "?";
  return `${url}${join}proba=${Date.now()}`;
}
