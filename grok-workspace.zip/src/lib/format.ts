export function formatMbps(value: number): string {
  const digits = value >= 10 ? 0 : 1;
  return `${value.toFixed(digits)} Мбит/с`;
}

export function formatMs(value: number): string {
  return String(Math.max(1, Math.round(value)));
}

export function grade(ms: number | null): string {
  if (ms == null) return "нет ответа";
  if (ms < 120) return "ровно";
  if (ms < 280) return "нормально";
  if (ms < 600) return "туго";
  return "плохо";
}

export function ticksFor(ms: number | null): number {
  if (ms == null) return 0;
  if (ms < 80) return 6;
  if (ms < 140) return 5;
  if (ms < 220) return 4;
  if (ms < 350) return 3;
  if (ms < 600) return 2;
  return 1;
}

export function countLabel(count: number): string {
  const mod10 = count % 10;
  const mod100 = count % 100;
  if (mod10 === 1 && mod100 !== 11) return `${count} узел`;
  if (mod10 >= 2 && mod10 <= 4 && (mod100 < 12 || mod100 > 14)) return `${count} узла`;
  return `${count} узлов`;
}

export function formatBytes(value: number): string {
  if (!Number.isFinite(value) || value < 0) return "—";
  const units = ["Б", "КБ", "МБ", "ГБ", "ТБ"];
  let n = value;
  let i = 0;
  while (n >= 1024 && i < units.length - 1) {
    n /= 1024;
    i += 1;
  }
  const digits = n >= 10 || i === 0 ? 0 : 1;
  return `${n.toFixed(digits)} ${units[i]}`;
}

export function formatWhen(at: number): string {
  try {
    return new Intl.DateTimeFormat("ru-RU", {
      hour: "2-digit",
      minute: "2-digit",
      day: "numeric",
      month: "short",
    }).format(new Date(at));
  } catch {
    return "";
  }
}

export function formatExpire(unix: number): string {
  if (!unix) return "без срока";
  try {
    return new Intl.DateTimeFormat("ru-RU", {
      day: "numeric",
      month: "short",
      year: "numeric",
    }).format(new Date(unix * 1000));
  } catch {
    return "";
  }
}
