import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { Sample } from "@/lib/probe";
import type { ServerNode, SubInfo } from "@/lib/parse-sub";

export type Profile = {
  id: string;
  name: string;
  source: "url" | "paste" | "file";
  url?: string;
  updatedAt: number;
  servers: ServerNode[];
  info?: SubInfo;
};

export type Stamp = {
  at: number;
  youtubeMs: number | null;
  zelloMs: number | null;
  grokMs: number | null;
  youtubeMbps: number | null;
  zelloMbps: number | null;
  grokMbps: number | null;
};

export type Check = {
  at: number;
  samples: Sample[];
};

export type RouteApp = {
  id: string;
  name: string;
  on: boolean;
};

type ProbaState = {
  profiles: Profile[];
  activeId: string | null;
  selectedId: string | null;
  stamps: Record<string, Stamp>;
  apps: RouteApp[];
  lastCheck: Check | null;
  upsertProfile: (profile: Profile) => void;
  removeProfile: (id: string) => void;
  setActive: (id: string) => void;
  setSelected: (id: string | null) => void;
  setLastCheck: (check: Check) => void;
  pinToSelected: () => void;
  toggleApp: (id: string) => void;
};

const DEFAULT_APPS: RouteApp[] = [
  { id: "youtube", name: "YouTube", on: true },
  { id: "zello", name: "Zello", on: true },
  { id: "grok", name: "Grok", on: true },
  { id: "browser", name: "Браузер", on: false },
  { id: "maps", name: "Карты", on: false },
  { id: "telegram", name: "Telegram", on: false },
];

export const useProba = create<ProbaState>()(
  persist(
    (set, get) => ({
      profiles: [],
      activeId: null,
      selectedId: null,
      stamps: {},
      apps: DEFAULT_APPS,
      lastCheck: null,
      upsertProfile: (profile) =>
        set((state) => {
          const index = state.profiles.findIndex((item) => item.id === profile.id);
          const profiles =
            index >= 0
              ? state.profiles.map((item) => (item.id === profile.id ? profile : item))
              : [profile, ...state.profiles];
          return { profiles, activeId: profile.id };
        }),
      removeProfile: (id) =>
        set((state) => {
          const profiles = state.profiles.filter((item) => item.id !== id);
          const active = state.activeId === id ? (profiles[0]?.id ?? null) : state.activeId;
          const activeProfile = profiles.find((item) => item.id === active);
          const selected =
            activeProfile?.servers.some((server) => server.id === state.selectedId) ? state.selectedId : null;
          return { profiles, activeId: active, selectedId: selected };
        }),
      setActive: (id) =>
        set((state) => {
          const profile = state.profiles.find((item) => item.id === id);
          const selected = profile?.servers.some((server) => server.id === state.selectedId)
            ? state.selectedId
            : null;
          return { activeId: id, selectedId: selected };
        }),
      setSelected: (id) => set({ selectedId: id }),
      setLastCheck: (check) => set({ lastCheck: check }),
      pinToSelected: () => {
        const { selectedId, lastCheck, stamps } = get();
        if (!selectedId || !lastCheck) return;
        const by = (id: Sample["id"]) => lastCheck.samples.find((sample) => sample.id === id);
        const youtube = by("youtube");
        const zello = by("zello");
        const grok = by("grok");
        set({
          stamps: {
            ...stamps,
            [selectedId]: {
              at: lastCheck.at,
              youtubeMs: youtube?.latencyMs ?? null,
              zelloMs: zello?.latencyMs ?? null,
              grokMs: grok?.latencyMs ?? null,
              youtubeMbps: youtube?.mbps ?? null,
              zelloMbps: zello?.mbps ?? null,
              grokMbps: grok?.mbps ?? null,
            },
          },
        });
      },
      toggleApp: (id) =>
        set((state) => ({
          apps: state.apps.map((app) => (app.id === id ? { ...app, on: !app.on } : app)),
        })),
    }),
    {
      name: "proba-v1",
      skipHydration: true,
      partialize: (state) => ({
        profiles: state.profiles,
        activeId: state.activeId,
        selectedId: state.selectedId,
        stamps: state.stamps,
        apps: state.apps,
        lastCheck: state.lastCheck,
      }),
    },
  ),
);
