import { createServerFn } from "@tanstack/react-start";

const MAX_BYTES = 1_500_000;

export const fetchSubscription = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    if (!input || typeof input !== "object" || !("url" in input)) {
      throw new Error("Нужна ссылка");
    }
    const url = String((input as { url: unknown }).url ?? "").trim();
    if (url.length < 8 || url.length > 2048) throw new Error("Ссылка слишком короткая или длинная");
    return { url };
  })
  .handler(async ({ data }) => {
    const fetched = await fetchChecked(data.url);
    return fetched;
  });

async function fetchChecked(rawUrl: string): Promise<{
  body: string;
  title?: string;
  userinfo?: string;
}> {
  let current = rawUrl;
  for (let hop = 0; hop < 4; hop += 1) {
    let url: URL;
    try {
      url = new URL(current);
    } catch {
      throw new Error("Ссылка не разбирается");
    }
    if (url.protocol !== "https:") throw new Error("Нужна ссылка, которая начинается с https");
    if (url.username || url.password) throw new Error("Эта ссылка не подходит");
    await assertPublicHost(url.hostname);
    const response = await fetch(url, {
      redirect: "manual",
      signal: AbortSignal.timeout(12_000),
      headers: {
        accept: "text/plain, application/octet-stream, */*",
        "user-agent": "Proba/1.0",
      },
    });
    if (response.status >= 300 && response.status < 400) {
      const location = response.headers.get("location");
      if (!location) throw new Error("Подписка вернула пустой переход");
      current = new URL(location, url).toString();
      continue;
    }
    if (!response.ok) throw new Error(`Подписка ответила кодом ${response.status}`);
    const declared = Number(response.headers.get("content-length") || 0);
    if (declared > MAX_BYTES) throw new Error("Подписка слишком большая");
    const buffer = await response.arrayBuffer();
    if (buffer.byteLength > MAX_BYTES) throw new Error("Подписка слишком большая");
    const body = new TextDecoder("utf-8", { fatal: false }).decode(buffer);
    return {
      body,
      title: decodeTitle(response.headers.get("profile-title") || response.headers.get("content-disposition")),
      userinfo: response.headers.get("subscription-userinfo") || undefined,
    };
  }
  throw new Error("Слишком много переходов по ссылке");
}

async function assertPublicHost(hostname: string) {
  const host = hostname.replace(/^\[|\]$/g, "").replace(/\.$/, "").toLowerCase();
  if (
    !host ||
    host === "localhost" ||
    host.endsWith(".local") ||
    host.endsWith(".internal") ||
    host === "metadata.google.internal" ||
    host.endsWith(".localhost")
  ) {
    throw new Error("Эта ссылка не подходит");
  }
  const { isIP } = await import("node:net");
  const { lookup } = await import("node:dns/promises");
  const ips: string[] = [];
  if (isIP(host)) ips.push(host);
  else {
    let records: Array<{ address: string }> = [];
    try {
      records = await lookup(host, { all: true, verbatim: true });
    } catch {
      throw new Error("Адрес подписки не открывается");
    }
    if (!records.length) throw new Error("Адрес подписки не открывается");
    for (const record of records) ips.push(record.address);
  }
  if (ips.some(isBlockedIp)) throw new Error("Эта ссылка не подходит");
}

function isBlockedIp(ip: string): boolean {
  const value = ip.toLowerCase();
  if (value.includes(":")) {
    if (value === "::1" || value === "::") return true;
    if (value.startsWith("fe80:") || value.startsWith("fc") || value.startsWith("fd")) return true;
    if (value.startsWith("::ffff:")) return isBlockedIp(value.slice(7));
    return false;
  }
  const parts = value.split(".").map((part) => Number(part));
  if (parts.length !== 4 || parts.some((n) => !Number.isInteger(n) || n < 0 || n > 255)) return true;
  const a = parts[0] ?? 0;
  const b = parts[1] ?? 0;
  if (a === 0 || a === 10 || a === 127 || a === 255) return true;
  if (a === 169 && b === 254) return true;
  if (a === 172 && b >= 16 && b <= 31) return true;
  if (a === 192 && b === 168) return true;
  if (a === 100 && b >= 64 && b <= 127) return true;
  return false;
}

function decodeTitle(header: string | null): string | undefined {
  if (!header) return undefined;
  let value = header.trim();
  const starred = value.match(/filename\*=UTF-8''([^;]+)/i);
  if (starred?.[1]) {
    try {
      value = decodeURIComponent(starred[1]);
    } catch {
      value = starred[1];
    }
  } else {
    const plain = value.match(/filename="?([^";]+)"?/i);
    if (plain?.[1]) value = plain[1];
  }
  if (value.toLowerCase().startsWith("base64:")) {
    try {
      value = Buffer.from(value.slice(7), "base64").toString("utf8");
    } catch {
      /* keep */
    }
  }
  try {
    value = decodeURIComponent(value);
  } catch {
    /* keep */
  }
  value = value.replace(/\.(txt|yaml|yml|json|conf)$/i, "").trim();
  return value.slice(0, 80) || undefined;
}
