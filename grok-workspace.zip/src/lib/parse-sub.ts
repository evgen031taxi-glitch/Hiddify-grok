export type ServerNode = {
  id: string;
  name: string;
  protocol: string;
  host: string;
  port: string;
};

export type SubInfo = {
  upload?: number;
  download?: number;
  total?: number;
  expire?: number;
};

const SKIP_TYPES = new Set([
  "selector",
  "urltest",
  "direct",
  "block",
  "dns",
  "reject",
  "compatible",
  "loadbalance",
  "fallback",
]);

const KEEPERS = new Set([
  "vless",
  "vmess",
  "trojan",
  "ss",
  "shadowsocks",
  "hysteria",
  "hysteria2",
  "hy2",
  "tuic",
  "wireguard",
  "socks",
  "socks5",
  "http",
  "ssh",
  "anytls",
  "mieru",
]);

export function unwrapSubUrl(raw: string): string {
  let s = raw.trim();
  const prefixes = [
    "happ://add/",
    "happ://crypt/",
    "happ://",
    "hiddify://import/",
    "hiddify://install-config/?url=",
    "hiddify://install-config?url=",
    "clash://install-config?url=",
    "clashmeta://install-config?url=",
    "v2rayng://install-sub?url=",
    "v2rayng://install-config?url=",
    "streisand://import/",
  ];
  const lower = s.toLowerCase();
  for (const prefix of prefixes) {
    if (lower.startsWith(prefix)) {
      s = s.slice(prefix.length);
      break;
    }
  }
  if (!/^https?:\/\//i.test(s) && /url=/i.test(s)) {
    const cut = s.split(/url=/i)[1] ?? "";
    s = cut.split("&")[0] ?? cut;
  }
  try {
    s = decodeURIComponent(s);
  } catch {
    /* keep */
  }
  return s.trim();
}

export function parseUserinfo(header?: string): SubInfo | undefined {
  if (!header) return undefined;
  const info: SubInfo = {};
  for (const part of header.split(";")) {
    const [keyRaw, valueRaw] = part.split("=");
    const key = keyRaw?.trim();
    const value = Number(valueRaw?.trim());
    if (!key || !Number.isFinite(value)) continue;
    if (key === "upload") info.upload = value;
    else if (key === "download") info.download = value;
    else if (key === "total") info.total = value;
    else if (key === "expire") info.expire = value;
  }
  return Object.keys(info).length ? info : undefined;
}

export function parseSubscription(raw: string): ServerNode[] {
  const text = raw.replace(/^\uFEFF/, "").trim();
  if (!text) return [];
  const direct = parseAny(text);
  if (direct.length) return direct;
  const decoded = tryDecodeBase64(text);
  if (!decoded || decoded === text) return [];
  return parseAny(decoded);
}

function parseAny(text: string): ServerNode[] {
  const trimmed = text.trim();
  if (trimmed.startsWith("{") || trimmed.startsWith("[")) {
    const fromJson = parseJson(trimmed);
    if (fromJson.length) return fromJson;
  }
  if (/^\s*proxies:/m.test(trimmed) || trimmed.includes("\nproxies:")) {
    const fromClash = parseClash(trimmed);
    if (fromClash.length) return fromClash;
  }
  return parseLines(trimmed);
}

function parseLines(text: string): ServerNode[] {
  const nodes: ServerNode[] = [];
  const seen = new Set<string>();
  for (const lineRaw of text.split(/\r?\n/)) {
    const line = lineRaw.trim();
    if (!line || line.startsWith("#") || line.startsWith("//")) continue;
    const node = parseShare(line);
    if (!node) continue;
    pushNode(nodes, seen, node);
  }
  return nodes;
}

function pushNode(nodes: ServerNode[], seen: Set<string>, node: ServerNode) {
  let id = node.id;
  let n = 2;
  while (seen.has(id)) {
    id = `${node.id}#${n}`;
    n += 1;
  }
  seen.add(id);
  nodes.push({ ...node, id });
}

function parseShare(line: string): ServerNode | null {
  const match = line.match(
    /^(vless|vmess|trojan|ss|hy2|hysteria2|hysteria|tuic|socks5|socks|anytls|wireguard):\/\/(\S+)/i,
  );
  if (!match) return null;
  const protocol = (match[1] ?? "").toLowerCase();
  const rest = match[2] ?? "";
  if (protocol === "vmess") return parseVmess(rest);
  if (protocol === "ss") return parseSs(rest);
  return parseStandard(protocol === "hy2" ? "hysteria2" : protocol, rest);
}

function parseStandard(protocol: string, rest: string): ServerNode | null {
  const { main, name } = splitName(rest);
  const noQuery = main.split("?")[0] ?? main;
  const at = noQuery.lastIndexOf("@");
  const hostport = at >= 0 ? noQuery.slice(at + 1) : noQuery;
  const hp = splitHostPort(hostport);
  if (!hp) return null;
  return makeNode(protocol, hp.host, hp.port, name || `${protocol} ${hp.host}`);
}

function parseSs(rest: string): ServerNode | null {
  const { main, name } = splitName(rest);
  const noQuery = main.split("?")[0] ?? main;
  if (noQuery.includes("@")) {
    const at = noQuery.lastIndexOf("@");
    const hp = splitHostPort(noQuery.slice(at + 1));
    if (!hp) return null;
    return makeNode("ss", hp.host, hp.port, name || `ss ${hp.host}`);
  }
  const decoded = tryDecodeBase64(noQuery);
  if (!decoded) return null;
  const at = decoded.lastIndexOf("@");
  if (at < 0) return null;
  const hp = splitHostPort(decoded.slice(at + 1));
  if (!hp) return null;
  return makeNode("ss", hp.host, hp.port, name || `ss ${hp.host}`);
}

function parseVmess(payload: string): ServerNode | null {
  const decoded = tryDecodeBase64(payload.split("#")[0] ?? payload);
  if (!decoded) return null;
  let data: unknown;
  try {
    data = JSON.parse(decoded);
  } catch {
    return null;
  }
  if (!data || typeof data !== "object") return null;
  const rec = data as Record<string, unknown>;
  const host = typeof rec.add === "string" ? rec.add : "";
  const port = rec.port != null ? String(rec.port) : "";
  const name = typeof rec.ps === "string" && rec.ps ? rec.ps : `vmess ${host}`;
  if (!host) return null;
  return makeNode("vmess", host, port || "443", name);
}

function parseJson(text: string): ServerNode[] {
  let data: unknown;
  try {
    data = JSON.parse(text);
  } catch {
    return [];
  }
  const list = extractList(data);
  const nodes: ServerNode[] = [];
  const seen = new Set<string>();
  for (const item of list) {
    if (!item || typeof item !== "object") continue;
    const rec = item as Record<string, unknown>;
    const typeRaw = typeof rec.type === "string" ? rec.type.toLowerCase() : "";
    if (!typeRaw || SKIP_TYPES.has(typeRaw)) continue;
    const protocol = typeRaw === "shadowsocks" ? "ss" : typeRaw;
    if (!KEEPERS.has(protocol) && !KEEPERS.has(typeRaw)) continue;
    const host =
      (typeof rec.server === "string" && rec.server) ||
      (typeof rec.address === "string" && rec.address) ||
      "";
    const portValue = rec.server_port ?? rec.port ?? rec.serverPort;
    const port = portValue != null ? String(portValue) : "443";
    const name =
      (typeof rec.tag === "string" && rec.tag) ||
      (typeof rec.name === "string" && rec.name) ||
      `${protocol} ${host}`;
    if (!host) continue;
    const node = makeNode(protocol, host, port, name);
    if (node) pushNode(nodes, seen, node);
  }
  return nodes;
}

function extractList(data: unknown): unknown[] {
  if (Array.isArray(data)) return data;
  if (!data || typeof data !== "object") return [];
  const rec = data as Record<string, unknown>;
  if (Array.isArray(rec.outbounds)) return rec.outbounds;
  if (Array.isArray(rec.proxies)) return rec.proxies;
  if (Array.isArray(rec.servers)) return rec.servers;
  return [];
}

function parseClash(text: string): ServerNode[] {
  const lines = text.split(/\r?\n/);
  let inProxies = false;
  const nodes: ServerNode[] = [];
  const seen = new Set<string>();
  let cur: { name?: string; type?: string; server?: string; port?: string } | null = null;

  const flush = () => {
    if (!cur?.server || !cur.type) {
      cur = null;
      return;
    }
    const protocol = cur.type.toLowerCase();
    if (SKIP_TYPES.has(protocol)) {
      cur = null;
      return;
    }
    const node = makeNode(
      protocol === "shadowsocks" ? "ss" : protocol,
      cur.server,
      cur.port || "443",
      cur.name || `${protocol} ${cur.server}`,
    );
    if (node) pushNode(nodes, seen, node);
    cur = null;
  };

  for (const line of lines) {
    if (!inProxies) {
      if (/^proxies:\s*(\[|$)/.test(line.trim()) || /^proxies:\s*$/.test(line)) {
        inProxies = true;
        const inline = line.split(/^proxies:\s*/).pop() ?? "";
        if (inline.trim().startsWith("[")) {
          const block = collectFlow(inline.trim());
          for (const node of parseFlowArray(block)) pushNode(nodes, seen, node);
          return nodes;
        }
      }
      continue;
    }
    if (/^[A-Za-z0-9_-]+:\s*$/.test(line)) {
      flush();
      break;
    }
    const flow = line.match(/^\s*-\s*\{(.+)\}\s*$/);
    if (flow?.[1]) {
      flush();
      const node = parseFlowItem(flow[1]);
      if (node) pushNode(nodes, seen, node);
      continue;
    }
    const named = line.match(/^\s*-\s*name:\s*(.+?)\s*$/);
    if (named?.[1]) {
      flush();
      cur = { name: unquote(named[1]) };
      continue;
    }
    if (!cur) continue;
    const kv = line.match(/^\s+(type|server|port):\s*(.+?)\s*$/);
    if (!kv) continue;
    const key = kv[1];
    const value = unquote(kv[2] ?? "");
    if (key === "type") cur.type = value;
    else if (key === "server") cur.server = value;
    else if (key === "port") cur.port = value;
  }
  flush();
  return nodes;
}

function collectFlow(start: string): string {
  return start;
}

function parseFlowArray(block: string): ServerNode[] {
  const inner = block.replace(/^\[/, "").replace(/\]\s*$/, "");
  const parts = inner.split(/\}\s*,\s*\{/);
  const nodes: ServerNode[] = [];
  for (const part of parts) {
    const node = parseFlowItem(part.replace(/^\{/, "").replace(/\}$/, ""));
    if (node) nodes.push(node);
  }
  return nodes;
}

function parseFlowItem(body: string): ServerNode | null {
  const pick = (key: string) => {
    const m = body.match(new RegExp(`(?:^|,)\\s*${key}\\s*:\\s*("[^"]*"|'[^']*'|[^,}]+)`));
    return m?.[1] ? unquote(m[1]) : "";
  };
  const name = pick("name");
  const type = pick("type");
  const server = pick("server");
  const port = pick("port");
  if (!type || !server || SKIP_TYPES.has(type.toLowerCase())) return null;
  const protocol = type.toLowerCase() === "shadowsocks" ? "ss" : type.toLowerCase();
  return makeNode(protocol, server, port || "443", name || `${protocol} ${server}`);
}

function splitName(rest: string): { main: string; name: string } {
  const hash = rest.lastIndexOf("#");
  if (hash < 0) return { main: rest, name: "" };
  let name = rest.slice(hash + 1);
  try {
    name = decodeURIComponent(name.replace(/\+/g, " "));
  } catch {
    /* keep */
  }
  return { main: rest.slice(0, hash), name };
}

function splitHostPort(value: string): { host: string; port: string } | null {
  const hp = value.replace(/\/$/, "");
  if (!hp) return null;
  if (hp.startsWith("[")) {
    const end = hp.indexOf("]");
    if (end < 0) return null;
    const host = hp.slice(1, end);
    const port = hp.slice(end + 1).replace(/^:/, "") || "443";
    return cleanHostPort(host, port);
  }
  const colon = hp.lastIndexOf(":");
  if (colon < 0) return cleanHostPort(hp, "443");
  return cleanHostPort(hp.slice(0, colon), hp.slice(colon + 1) || "443");
}

function cleanHostPort(host: string, port: string): { host: string; port: string } | null {
  const h = host.trim();
  const p = (port.trim().match(/^\d{1,5}/)?.[0] ?? "").replace(/^0+(?=\d)/, "");
  if (!h || h.length > 253 || /\s/.test(h)) return null;
  const n = Number(p || "443");
  if (!Number.isInteger(n) || n < 1 || n > 65535) return null;
  return { host: h, port: String(n) };
}

function makeNode(protocol: string, host: string, port: string, name: string): ServerNode | null {
  const hp = cleanHostPort(host, port);
  if (!hp) return null;
  const proto = protocol.toLowerCase();
  const label = name.replace(/\s+/g, " ").trim().slice(0, 80) || `${proto} ${hp.host}`;
  return {
    id: `${proto}|${hp.host}|${hp.port}|${label}`.slice(0, 180),
    name: label,
    protocol: proto,
    host: hp.host,
    port: hp.port,
  };
}

function unquote(value: string): string {
  const trimmed = value.trim().replace(/\s+#.*$/, "");
  if (
    (trimmed.startsWith('"') && trimmed.endsWith('"')) ||
    (trimmed.startsWith("'") && trimmed.endsWith("'"))
  ) {
    return trimmed.slice(1, -1);
  }
  return trimmed;
}

function tryDecodeBase64(value: string): string | null {
  const compact = value.replace(/\s/g, "");
  if (compact.length < 8 || !/^[A-Za-z0-9+/_=-]+$/.test(compact)) return null;
  const pad = compact.replace(/-/g, "+").replace(/_/g, "/");
  const padded = pad + "=".repeat((4 - (pad.length % 4)) % 4);
  try {
    const bytes =
      typeof atob === "function"
        ? Uint8Array.from(atob(padded), (c) => c.charCodeAt(0))
        : Uint8Array.from(Buffer.from(padded, "base64"));
    const text = new TextDecoder("utf-8", { fatal: false }).decode(bytes);
    if (!text || text.includes("\u0000")) return null;
    return text;
  } catch {
    return null;
  }
}
